CrystalDiskInfo in den Build einbinden

Lege die portable CrystalDiskInfo-Version direkt in diesen Ordner, zum Beispiel:

CrystalDiskInfo\DiskInfo64.exe
CrystalDiskInfo\DiskInfo32.exe
CrystalDiskInfo\CdiResource\...
CrystalDiskInfo\License\...

Beim Build/Publish kopiert das Projekt den Inhalt dieses Ordners automatisch direkt neben NvmeUsbQuickCheck.exe in den Publish-Ordner.
Im fertigen Publish-Ordner gibt es dadurch keinen separaten tools-Ordner für CrystalDiskInfo.

Wichtig: CrystalDiskInfo selbst wird hier nicht mitgeliefert. Du musst die portable Version selbst in diesen Ordner legen.
