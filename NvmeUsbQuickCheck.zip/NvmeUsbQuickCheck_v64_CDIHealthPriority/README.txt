NvmeUsbQuickCheck v63 ColumnLayout
==================================

Basis: v62 WearLevelHealthFix.

Änderungen v63:
- Spalten der Ergebnisliste können nun manuell mit der Maus in der Breite verändert werden.
- Die geänderten Spaltenbreiten werden in den Programmeinstellungen gespeichert.
- Beim nächsten Programmstart werden die gespeicherten Spaltenbreiten wiederhergestellt.
- Gilt für alle Spalten der Ergebnisliste: Zeit, Ergebnis, Name, Seriennummer, Größe, Health, SMART, Hours, R/W.
- Testlogik, Formatierung, SMART/CDI, Max-Wear und R/W-Test bleiben unverändert.

Build:
  powershell -ExecutionPolicy Bypass -File .\Build-Standalone.ps1


Version 64 - CDI Health Priority:
- CrystalDiskInfo Health/Gesamtzustand-Prozentwert hat jetzt Vorrang vor einzelnen WLC/Life/Percentage-Attributen.
- Beispiel: CDI zeigt Health 87 %, dann wird Wear 13 % berechnet, auch wenn ein einzelnes SMART-Attribut 13 enthält.
- Das behebt SK hynix/SATA-Fälle, bei denen WLC/Life-Werte verdreht bewertet wurden.
