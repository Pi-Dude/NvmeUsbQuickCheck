param(
    [ValidateSet("win-x64", "win-arm64")]
    [string]$Runtime = "win-x64"
)

$ErrorActionPreference = "Stop"

Write-Host "Baue Standalone-EXE für $Runtime ..." -ForegroundColor Cyan

if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    Write-Host "Das .NET SDK wurde nicht gefunden." -ForegroundColor Red
    Write-Host "Installiere das Microsoft .NET 8 SDK und starte dieses Script erneut."
    exit 1
}

$project = Join-Path $PSScriptRoot "NvmeUsbQuickCheck.csproj"
$outDir = Join-Path $PSScriptRoot "publish\$Runtime-standalone"

if (Test-Path $outDir) {
    Remove-Item $outDir -Recurse -Force
}

# Alte Zwischenstände löschen, damit keine kaputten Preview-SDK-Caches stören.
$bin = Join-Path $PSScriptRoot "bin"
$obj = Join-Path $PSScriptRoot "obj"
if (Test-Path $bin) { Remove-Item $bin -Recurse -Force }
if (Test-Path $obj) { Remove-Item $obj -Recurse -Force }

# Eine einzelne EXE inklusive .NET Runtime erzeugen.
dotnet publish $project `
    -c Release `
    -r $Runtime `
    --self-contained true `
    /p:PublishSingleFile=true `
    /p:IncludeNativeLibrariesForSelfExtract=true `
    /p:EnableCompressionInSingleFile=true `
    /p:DebugType=None `
    /p:DebugSymbols=false `
    /p:StartupObject=NvmeUsbQuickCheck.Program `
    -o $outDir

$exe = Join-Path $outDir "NvmeUsbQuickCheck.exe"

if (Test-Path $exe) {
    Write-Host "Fertig:" -ForegroundColor Green
    Write-Host $exe
} else {
    Write-Host "Build beendet, aber EXE wurde nicht gefunden." -ForegroundColor Red
    Write-Host "Inhalt des Publish-Ordners:" -ForegroundColor Yellow
    if (Test-Path $outDir) { Get-ChildItem $outDir | Format-Table Name, Length }
    exit 2
}
