using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Media;
using System.Security.Principal;
using Microsoft.Win32.SafeHandles;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Windows.Forms;

namespace NvmeUsbQuickCheck
{

public static class Program
{
    [STAThread]
    public static void Main(string[] args)
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new MainForm());
    }
}

internal sealed class MainForm : Form
{
    private readonly ComboBox _sizeDropDown = new();
    private readonly NumericUpDown _tolerance = new();
    private readonly CheckBox _failIfSmartUnknown = new();
    private readonly CheckBox _onlyUsb = new();
    private readonly CheckBox _quickReadWriteTest = new();
    private readonly CheckBox _rwSize128 = new();
    private readonly CheckBox _rwSize256 = new();
    private readonly CheckBox _rwSize512 = new();
    private readonly NumericUpDown _minSpeed = new();
    private readonly ComboBox _maxWearDropDown = new();
    private readonly ComboBox _minSpareDropDown = new();
    private readonly ComboBox _maxTemperatureDropDown = new();
    private readonly ComboBox _maxWriteErrDropDown = new();
    private readonly ComboBox _exportFilterDropDown = new();
    private readonly Button _exportPdf = new();
    private readonly Button _exportCsv = new();
    private readonly Button _startStop = new();
    private readonly Label _status = new();
    private readonly TextBox _details = new();
    private readonly DataGridView _history = new();
    private readonly System.Windows.Forms.Timer _timer = new();
    private readonly HashSet<string> _currentlyPresent = new(StringComparer.OrdinalIgnoreCase);
    private readonly List<ExportResultSnapshot> _exportResults = new();
    private readonly AppSettings _appSettings = AppSettings.Load();

    private bool _isScanning;
    private bool _isRunning = true;
    private bool _loadingSettings;
    private bool _deviceChangeRescanRequested;
    private bool _restoringHistoryColumnLayout;
    private int _scanErrorCount;
    private DateTime _nextScanAllowedUtc = DateTime.MinValue;
    private DateTime _ignoreDeviceChangesUntilUtc = DateTime.MinValue;

    private const int WmDeviceChange = 0x0219;

    private const int StorageSettleDelayMs = 250;
    private const int WritableReadyTimeoutMs = 2000;

    public MainForm()
    {
        Text = "USB-NVMe Schnelltest";
        MinimumSize = new Size(1300, 884);
        Size = new Size(1300, 884);
        StartPosition = FormStartPosition.CenterScreen;
        Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);

        CsvResultExporter.CleanupOldDailyLogs(_appSettings.LogRetentionDays);
        DeleteLegacySmartFolderOnStartup();
        BuildUi();

        if (!IsAdministrator())
        {
            SetStatus("Warnung: Programm läuft nicht als Administrator. SMART-Werte können fehlen.", Color.DarkOrange);
        }
        else
        {
            SetStatus("Überwachung läuft. USB-NVMe einstecken.", Color.DodgerBlue);
        }

        _timer.Interval = 2000;
        _timer.Tick += TimerOnTick;
        _timer.Start();
    }

    private static void DeleteLegacySmartFolderOnStartup()
    {
        try
        {
            var smartFolder = Path.Combine(AppContext.BaseDirectory, "tools", "Smart");
            if (Directory.Exists(smartFolder))
                Directory.Delete(smartFolder, recursive: true);
        }
        catch
        {
            // Alter SMART-Cache ist nicht testkritisch. Wenn eine Datei gesperrt ist, läuft die App weiter.
        }
    }

    private void BuildUi()
    {
        var outer = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 2,
        };
        outer.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        outer.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        Controls.Add(outer);

        var topBar = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false,
            AutoSize = true,
            Padding = new Padding(12, 8, 12, 0),
            Margin = new Padding(0),
        };

        var settingsButton = new Button
        {
            Text = "Einstellungen",
            Width = 120,
            Height = 28,
            Margin = new Padding(0, 0, 8, 0),
        };
        settingsButton.Click += (_, _) => OpenSettingsDialog();
        topBar.Controls.Add(settingsButton);
        outer.Controls.Add(topBar, 0, 0);

        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 4,
            Padding = new Padding(12),
        };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 132));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 70));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 60));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 40));
        outer.Controls.Add(root, 0, 1);

        var settings = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 8,
            RowCount = 3,
        };
        settings.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 120));
        settings.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 180));
        settings.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 100));
        settings.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 120));
        settings.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 250));
        settings.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 170));
        settings.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 140));
        settings.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        settings.RowStyles.Add(new RowStyle(SizeType.Absolute, 45));
        settings.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
        settings.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
        root.Controls.Add(settings, 0, 0);

        settings.Controls.Add(new Label { Text = "Sollgröße", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, 0);
        _sizeDropDown.DropDownStyle = ComboBoxStyle.DropDownList;
        _sizeDropDown.Dock = DockStyle.Fill;
        _sizeDropDown.Items.AddRange(new object[]
        {
            new SizeOption("128 GB", 128),
            new SizeOption("256 GB", 256),
            new SizeOption("512 GB", 512),
            new SizeOption("1 TB / 1000 GB", 1000),
            new SizeOption("2 TB / 2000 GB", 2000),
            new SizeOption("4 TB / 4000 GB", 4000),
            new SizeOption("8 TB / 8000 GB", 8000),
        });
        _loadingSettings = true;
        _sizeDropDown.SelectedIndex = 0; // Erststart-Standard: 128 GB
        RestoreLastSelectedSize();
        _loadingSettings = false;
        _sizeDropDown.SelectedIndexChanged += (_, _) => SaveCurrentSizeSelection();
        settings.Controls.Add(_sizeDropDown, 1, 0);

        settings.Controls.Add(new Label { Text = "Toleranz", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 2, 0);
        _tolerance.Minimum = 0;
        _tolerance.Maximum = 50;
        _tolerance.DecimalPlaces = 1;
        _tolerance.Increment = 0.5M;
        _tolerance.Value = 5;
        _tolerance.Dock = DockStyle.Fill;
        settings.Controls.Add(_tolerance, 3, 0);

        _failIfSmartUnknown.Text = "SMART unbekannt = Fehler"; // Standard aus: CDI/smartctl optional
        _failIfSmartUnknown.Checked = false;
        _failIfSmartUnknown.Dock = DockStyle.Fill;
        settings.Controls.Add(_failIfSmartUnknown, 4, 0);

        _onlyUsb.Text = "nur USB-Datenträger";
        _onlyUsb.Checked = true;
        _onlyUsb.Dock = DockStyle.Fill;
        settings.Controls.Add(_onlyUsb, 5, 0);

        _startStop.Text = "Stoppen";
        _startStop.Dock = DockStyle.Fill;
        _startStop.Click += (_, _) => ToggleRunning();
        settings.Controls.Add(_startStop, 6, 0);

        _quickReadWriteTest.Text = "R/W-Test, automatisch initialisieren/formatieren";
        _quickReadWriteTest.Checked = true;
        _quickReadWriteTest.Dock = DockStyle.Fill;
        settings.SetColumnSpan(_quickReadWriteTest, 3);
        settings.Controls.Add(_quickReadWriteTest, 0, 1);

        settings.Controls.Add(new Label { Text = "Min. R/W MB/s", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 3, 1);
        _minSpeed.Minimum = 0;
        _minSpeed.Maximum = 5000;
        _minSpeed.DecimalPlaces = 0;
        _minSpeed.Increment = 10;
        _minSpeed.Value = ClampDecimal(_appSettings.MinReadWriteSpeedMBs, _minSpeed.Minimum, _minSpeed.Maximum);
        _minSpeed.Dock = DockStyle.Left;
        _minSpeed.Width = 75; // ca. 70 % kleiner als das bisherige 250-px-Feld
        _minSpeed.ValueChanged += (_, _) => SaveCurrentMinimumSpeedSelection();
        settings.Controls.Add(_minSpeed, 4, 1);

        settings.Controls.Add(new Label { Text = "Max. Wear", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 5, 1);
        _maxWearDropDown.DropDownStyle = ComboBoxStyle.DropDownList;
        _maxWearDropDown.Dock = DockStyle.Fill;
        for (var wear = 10; wear <= 45; wear += 5)
            _maxWearDropDown.Items.Add(new WearOption($"{wear}%", wear));
        RestoreMaximumWearSelection();
        _maxWearDropDown.SelectedIndexChanged += (_, _) => SaveCurrentMaximumWearSelection();
        settings.Controls.Add(_maxWearDropDown, 6, 1);

        settings.Controls.Add(new Label { Text = "Schreibtest", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, 2);
        var rwSizePanel = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false,
            Margin = new Padding(0),
            Padding = new Padding(0),
        };

        ConfigureReadWriteSizeCheckBox(_rwSize128, "128 MB", 128);
        ConfigureReadWriteSizeCheckBox(_rwSize256, "256 MB", 256);
        ConfigureReadWriteSizeCheckBox(_rwSize512, "512 MB", 512);
        rwSizePanel.Controls.Add(_rwSize128);
        rwSizePanel.Controls.Add(_rwSize256);
        rwSizePanel.Controls.Add(_rwSize512);
        settings.SetColumnSpan(rwSizePanel, 4);
        settings.Controls.Add(rwSizePanel, 1, 2);
        RestoreReadWriteTestSizeSelection();

        settings.Controls.Add(new Label { Text = "PDF Export", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 5, 2);
        _exportFilterDropDown.DropDownStyle = ComboBoxStyle.DropDownList;
        _exportFilterDropDown.Dock = DockStyle.Fill;
        _exportFilterDropDown.Items.AddRange(new object[]
        {
            new ExportFilterOption("Alle", null),
            new ExportFilterOption("nur BESTANDEN", "BESTANDEN"),
            new ExportFilterOption("nur FEHLER", "FEHLER"),
        });
        _exportFilterDropDown.SelectedIndex = 0;
        settings.Controls.Add(_exportFilterDropDown, 6, 2);

        var exportButtonPanel = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 1,
            Margin = new Padding(0),
            Padding = new Padding(0),
        };
        exportButtonPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        exportButtonPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));

        _exportPdf.Text = "PDF speichern";
        _exportPdf.Dock = DockStyle.Fill;
        _exportPdf.Click += ExportPdfOnClick;
        exportButtonPanel.Controls.Add(_exportPdf, 0, 0);

        _exportCsv.Text = "CSV speichern";
        _exportCsv.Dock = DockStyle.Fill;
        _exportCsv.Click += ExportCsvOnClick;
        exportButtonPanel.Controls.Add(_exportCsv, 1, 0);

        settings.Controls.Add(exportButtonPanel, 7, 2);

        _status.Dock = DockStyle.Fill;
        _status.Font = new Font(Font.FontFamily, 18F, FontStyle.Bold);
        _status.TextAlign = ContentAlignment.MiddleCenter;
        _status.BorderStyle = BorderStyle.FixedSingle;
        root.Controls.Add(_status, 0, 1);

        _history.Dock = DockStyle.Fill;
        _history.AllowUserToAddRows = false;
        _history.AllowUserToDeleteRows = false;
        _history.AllowUserToResizeRows = false;
        _history.ReadOnly = true;
        _history.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        _history.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;
        _history.ScrollBars = ScrollBars.Both;
        _history.RowHeadersVisible = false;
        _history.EnableHeadersVisualStyles = false;
        _history.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        _history.ColumnHeadersDefaultCellStyle.Font = new Font(Font.FontFamily, 10F, FontStyle.Bold, GraphicsUnit.Point);
        _history.RowTemplate.Height = 30; // ca. 20 % mehr vertikaler Platz pro Ergebniszeile
        _history.ColumnHeadersHeight = 32;
        _history.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None;
        _history.Columns.Add("Time", "Zeit");
        _history.Columns.Add("Result", "Ergebnis");
        _history.Columns.Add("Name", "Name");
        _history.Columns.Add("Serial", "Seriennummer");
        _history.Columns.Add("Size", "Größe");
        _history.Columns.Add("Health", "Health");
        _history.Columns.Add("Smart", "SMART");
        _history.Columns.Add("PowerOnHours", "Hours");
        _history.Columns.Add("ReadWrite", "R/W");
        ApplyHistoryColumnLayout();
        _history.ColumnWidthChanged += (_, _) => SaveHistoryColumnLayout();
        root.Controls.Add(_history, 0, 2);

        _details.Dock = DockStyle.Fill;
        _details.Multiline = true;
        _details.ScrollBars = ScrollBars.Both;
        _details.WordWrap = false;
        _details.ReadOnly = true;
        _details.Font = new Font("Consolas", 10F, FontStyle.Regular, GraphicsUnit.Point);
        root.Controls.Add(_details, 0, 3);
    }

    protected override void WndProc(ref Message m)
    {
        base.WndProc(ref m);

        if (m.Msg == WmDeviceChange && _isRunning)
        {
            // Formatieren, Assign und CrystalDiskInfo können während und kurz nach einem Test
            // mehrere WM_DEVICECHANGE-Ereignisse erzeugen. Diese dürfen die Präsenzliste nicht
            // leeren, sonst wird dasselbe Laufwerk wenige Sekunden später erneut getestet.
            if (_isScanning || DateTime.UtcNow < _ignoreDeviceChangesUntilUtc)
                return;

            _deviceChangeRescanRequested = true;
        }
    }

    private async void TimerOnTick(object? sender, EventArgs e)
    {
        if (!_isRunning || _isScanning)
            return;

        if (DateTime.UtcNow < _nextScanAllowedUtc)
            return;

        _isScanning = true;
        try
        {
            if (_deviceChangeRescanRequested)
            {
                // Gerätewechsel durch Format/Assign/CDI darf die Sperrliste nicht leeren.
                // Entfernte Laufwerke werden weiter unten über currentKeys zuverlässig entfernt.
                _deviceChangeRescanRequested = false;
            }

            var allDisks = await DiskScanner.GetPhysicalDisksAsync(enrichWithSmartCtl: false);
            var disks = allDisks
                .Where(d => d.SizeBytes > 32UL * 1000UL * 1000UL * 1000UL)
                .Where(d => !_onlyUsb.Checked || string.Equals(d.BusType, "USB", StringComparison.OrdinalIgnoreCase))
                .ToList();

            _scanErrorCount = 0;
            _nextScanAllowedUtc = DateTime.MinValue;

            var currentKeys = disks.Select(d => d.PresenceKey).ToHashSet(StringComparer.OrdinalIgnoreCase);

            foreach (var oldKey in _currentlyPresent.Except(currentKeys, StringComparer.OrdinalIgnoreCase).ToList())
                _currentlyPresent.Remove(oldKey);

            var diskToTest = disks.FirstOrDefault(d => !_currentlyPresent.Contains(d.PresenceKey));

            if (diskToTest != null)
            {
                _currentlyPresent.Add(diskToTest.PresenceKey);
                _ignoreDeviceChangesUntilUtc = DateTime.UtcNow.AddMinutes(3);

                SetStatus($"Laufwerk erkannt: {diskToTest.FriendlyName} – Test läuft ...", Color.DarkOrange);
                await Task.Delay(100);

                var result = await EvaluateAsync(diskToTest);
                AddResult(result);
                _ignoreDeviceChangesUntilUtc = DateTime.UtcNow.AddSeconds(8);

                if (result.Passed)
                {
                    PlayPassSound();
                    SetStatus("BESTANDEN – Überwachung läuft. Nächstes Laufwerk einstecken.", Color.ForestGreen);
                }
                else
                {
                    PlayFailSound();
                    SetStatus("FEHLER – Überwachung läuft. Laufwerk prüfen/wechseln.", Color.Firebrick);
                }

                // Kein sofortiger zweiter PowerShell-Scan nach dem Test.
                // Das reduziert Storage-Stack-Last und verhindert Hänger auf empfindlichen USB-NVMe-Bridges.
                _currentlyPresent.Add(diskToTest.PresenceKey);

                return;
            }

            if (currentKeys.Count == 0)
            {
                _currentlyPresent.Clear();
                if (_isRunning)
                    SetStatus("Überwachung läuft. USB-NVMe einstecken.", Color.DodgerBlue);
            }
            else if (_isRunning && _status.Text.StartsWith("BESTANDEN", StringComparison.OrdinalIgnoreCase))
            {
                SetStatus("Überwachung läuft. Geprüftes Laufwerk entfernen oder neues einstecken.", Color.DodgerBlue);
            }
        }
        catch (Exception ex)
        {
            _scanErrorCount++;
            var waitSeconds = Math.Min(30, 5 * _scanErrorCount);
            _nextScanAllowedUtc = DateTime.UtcNow.AddSeconds(waitSeconds);

            SetStatus($"Scan wartet {waitSeconds}s – {ShortError(ex.Message)}", Color.DarkOrange);
            _details.Text = "Überwachungs-Scan wurde abgefangen; kein Laufwerk wurde als Fehler bewertet."
                + Environment.NewLine + ex.Message;

            // Kein Fehlerton: Ein Scan-Timeout ist kein SSD-Prüffehler.
        }
        finally
        {
            _isScanning = false;
        }
    }

    private static string ShortError(string? message)
    {
        if (string.IsNullOrWhiteSpace(message))
            return "unbekannter Scanfehler";

        var oneLine = message.Replace("\r", " ").Replace("\n", " ").Trim();
        return oneLine.Length <= 120 ? oneLine : oneLine[..120] + " ...";
    }

    private async Task<CheckResult> EvaluateAsync(DiskInfo disk)
    {
        // CrystalDiskInfo und smartctl sind optional und können bei manchen USB-Bridges mehrere Sekunden brauchen.
        // Deshalb nur für den tatsächlich zu testenden Datenträger, nicht in jedem Scan.
        // Reihenfolge bewusst: CrystalDiskInfo liefert für viele SSDs den Life-/Wear-Prozentwert
        // zuverlässiger als Windows; smartctl ergänzt danach nur fehlende Details.
        await CrystalDiskInfoProvider.EnrichAsync(disk);
        await SmartCtl.EnrichAsync(disk);

        var sizeOption = (SizeOption)_sizeDropDown.SelectedItem!;
        var expectedBytes = sizeOption.Gigabytes * 1000d * 1000d * 1000d;
        var tolerance = (double)_tolerance.Value / 100d;
        var minBytes = expectedBytes * (1d - tolerance);
        var maxBytes = expectedBytes * (1d + tolerance);

        var notes = new List<string>();
        var sizeOk = disk.SizeBytes >= minBytes && disk.SizeBytes <= maxBytes;
        var healthOk = IsWindowsHealthOk(disk.HealthStatus, disk.OperationalStatus);

        var smartOk = true;
        var smartSummary = "OK";

        if (!disk.SmartAvailable)
        {
            smartOk = !_failIfSmartUnknown.Checked;
            smartSummary = "n/v";
            notes.Add(_failIfSmartUnknown.Checked
                ? "SMART/Reliability ist nicht verfügbar und wird wegen aktivierter Option als Fehler bewertet."
                : "SMART/Reliability ist nicht verfügbar; kein Fehler, weil die Option 'SMART unbekannt = Fehler' deaktiviert ist.");
        }
        else
        {
            if (!string.IsNullOrWhiteSpace(disk.SmartSource))
                notes.Add($"SMART-Quelle: {disk.SmartSource}.");

            if (disk.SmartStatusPassed.HasValue && !disk.SmartStatusPassed.Value)
            {
                smartOk = false;
                notes.Add("SMART-Gesamtstatus meldet Fehler.");
            }

            if (disk.CriticalWarning.GetValueOrDefault() > 0)
            {
                smartOk = false;
                notes.Add($"NVMe CriticalWarning={disk.CriticalWarning}");
            }

            if (disk.ReadErrorsTotal.GetValueOrDefault() > 0)
            {
                smartOk = false;
                notes.Add($"ReadErrorsTotal/MediaErrors={disk.ReadErrorsTotal}");
            }

            var maxWriteErrors = SelectedMaximumWriteErrorsTotal();
            var writeErrorsTotal = disk.WriteErrorsTotal.GetValueOrDefault();
            if (writeErrorsTotal >= maxWriteErrors)
            {
                smartOk = false;
                notes.Add($"WriteErrorsTotal={disk.WriteErrorsTotal} >= Maximum {maxWriteErrors}");
            }
            else if (writeErrorsTotal > 0)
            {
                notes.Add($"WriteErrorsTotal={disk.WriteErrorsTotal} < Maximum {maxWriteErrors}, kein Fehler");
            }

            var maxTemperatureC = SelectedMaximumTemperatureC();
            if (disk.Temperature.GetValueOrDefault() >= maxTemperatureC)
            {
                smartOk = false;
                notes.Add($"Temperatur={disk.Temperature} °C >= Maximum {maxTemperatureC} °C");
            }

            var maxWearPercent = SelectedMaximumWearPercent();
            if (disk.Wear.HasValue && disk.Wear.Value > maxWearPercent)
            {
                smartOk = false;
                notes.Add($"Wear/PercentageUsed={disk.Wear}% > Maximum {maxWearPercent}%");
            }

            if (disk.LifeRemaining.HasValue && disk.LifeRemaining.Value < 100 - maxWearPercent)
            {
                smartOk = false;
                notes.Add($"SSD Life Remaining={disk.LifeRemaining}% < Minimum {100 - maxWearPercent}%");
            }

            var minSparePercent = SelectedMinimumSparePercent();
            if (disk.AvailableSpare.HasValue && disk.AvailableSpare.Value < minSparePercent)
            {
                smartOk = false;
                notes.Add($"NVMe Available Spare={disk.AvailableSpare}% < Minimum {minSparePercent}%");
            }
            else if (disk.AvailableSpare.HasValue)
            {
                if (disk.AvailableSpareThreshold.HasValue)
                    notes.Add($"NVMe Available Spare={disk.AvailableSpare}% >= Minimum {minSparePercent}% (Hersteller-Threshold={disk.AvailableSpareThreshold}%).");
                else
                    notes.Add($"NVMe Available Spare={disk.AvailableSpare}% >= Minimum {minSparePercent}%.");
            }

            if (disk.ReallocatedSectors.GetValueOrDefault() > 0)
            {
                smartOk = false;
                notes.Add($"Reallocated Sectors={disk.ReallocatedSectors}");
            }

            if (disk.PendingSectors.GetValueOrDefault() > 0)
            {
                smartOk = false;
                notes.Add($"Pending Sectors={disk.PendingSectors}");
            }

            if (disk.UncorrectableErrors.GetValueOrDefault() > 0)
            {
                smartOk = false;
                notes.Add($"Uncorrectable Errors={disk.UncorrectableErrors}");
            }

            if (disk.CrcErrors.GetValueOrDefault() > 0)
            {
                smartOk = false;
                notes.Add($"CRC/Interface Errors={disk.CrcErrors}");
            }

            if (!string.IsNullOrWhiteSpace(disk.WearLevelText))
            {
                notes.Add($"Wear-Leveling: {disk.WearLevelText}.");
            }

            if (smartOk)
            {
                notes.Add("SMART/Reliability unauffällig.");
            }
            else
            {
                smartSummary = "Fehler";
            }
        }

        if (!sizeOk)
        {
            notes.Add($"Größe außerhalb der Toleranz: Ist {FormatGb(disk.SizeBytes)}; Soll {sizeOption.Gigabytes:N0} GB ± {_tolerance.Value:N1}%.");
        }

        if (!healthOk)
        {
            notes.Add($"Windows Health auffällig: HealthStatus={disk.HealthStatus}; OperationalStatus={disk.OperationalStatus}.");
        }

        var readWriteTestMegabytes = SelectedReadWriteTestMegabytes();
        var readWrite = _quickReadWriteTest.Checked
            ? await RunQuickReadWriteTestAsync(disk, (double)_minSpeed.Value, readWriteTestMegabytes)
            : new ReadWriteTestResult(false, true, "deaktiviert", "Der kurze Read/Write-Test ist deaktiviert.");

        if (!readWrite.Passed)
        {
            notes.Add(readWrite.Details ?? readWrite.Summary);
        }

        var passed = sizeOk && healthOk && smartOk && readWrite.Passed;


        return new CheckResult(
            disk,
            Passed: passed,
            SizeOk: sizeOk,
            HealthOk: healthOk,
            SmartOk: smartOk,
            ReadWriteOk: readWrite.Passed,
            SmartSummary: smartSummary,
            ReadWriteSummary: readWrite.Summary,
            Details: BuildDetails(disk, sizeOption, sizeOk, healthOk, smartOk, readWrite, passed, notes));
    }

    private static async Task<ReadWriteTestResult> RunQuickReadWriteTestAsync(DiskInfo disk, double minMegabytesPerSecond, int testMegabytes)
    {
        testMegabytes = Math.Clamp(testMegabytes, 128, 512);
        var testBytes = testMegabytes * 1024 * 1024;

        string? testRoot = null;
        var preparationNote = string.Empty;

        // Für einen reproduzierbaren Serientest wird der Testdatenträger immer frisch vorbereitet:
        // online schalten, initialisieren, löschen, GPT/NTFS-Testpartition anlegen und per Laufwerksbuchstaben bereitstellen.
        if (disk.DiskNumber.HasValue && disk.DiskNumber.Value >= 0)
        {
            var mountResult = await DiskScanner.EnsureMountedOrPrepareForReadWriteAsync(disk);
            if (!mountResult.Success)
            {
                return new ReadWriteTestResult(
                    true,
                    false,
                    "Initialisierung/Format fehlgeschlagen",
                    "Read/Write-Test nicht möglich: " + mountResult.Message);
            }

            testRoot = !string.IsNullOrWhiteSpace(mountResult.TestPath)
                ? mountResult.TestPath
                : SplitDriveLetters(mountResult.DriveLetters).Select(letter => letter + @":\").FirstOrDefault();
            preparationNote = mountResult.Action;
        }
        else
        {
            testRoot = SplitDriveLetters(disk.DriveLetters)
                .Select(letter => letter + @":\")
                .FirstOrDefault();
        }

        if (string.IsNullOrWhiteSpace(testRoot))
        {
            return new ReadWriteTestResult(
                true,
                false,
                "kein Testpfad",
                "Read/Write-Test nicht möglich: Es wurde kein nutzbarer Testpfad gefunden.");
        }

        testRoot = NormalizeTestRoot(testRoot);

        // Nach Format/Mount braucht der Windows-Storage-Stack bei manchen USB-NVMe-Adaptern
        // einen kurzen Moment, bevor Dateizugriffe zuverlässig funktionieren.
        await Task.Delay(StorageSettleDelayMs);

        var writable = await WaitForWritablePathAsync(testRoot, WritableReadyTimeoutMs);
        if (!writable)
        {
            return new ReadWriteTestResult(
                true,
                false,
                "Pfad nicht bereit",
                "Read/Write-Test nicht möglich: Der Mount-/Laufwerkspfad war nach 2000 ms nicht schreibbereit: " + testRoot);
        }

        var filePath = Path.Combine(testRoot, $"NvmeUsbQuickCheck_{Guid.NewGuid():N}.bin");

        try
        {
            Directory.CreateDirectory(testRoot);

            // Direct I/O: Datei mit FILE_FLAG_NO_BUFFERING öffnen, damit der Windows-Systemcache
            // den Lesetest nicht verfälscht. FILE_FLAG_WRITE_THROUGH wird bewusst nicht verwendet,
            // weil einige USB-NVMe-Bridges dadurch den Windows-Storage-Stack blockieren können.
            var benchmark = await Task.Run(() => DirectIoBenchmark.Run(filePath, testBytes));

            if (benchmark.TotalRead != testBytes)
            {
                return new ReadWriteTestResult(true, false, "Lesefehler", $"Direct-I/O-Test fehlgeschlagen: Erwartet {testBytes:N0} Bytes, gelesen {benchmark.TotalRead:N0} Bytes.");
            }

            if (!benchmark.HashOk)
            {
                return new ReadWriteTestResult(true, false, "Datenvergleich fehlerhaft", "Direct-I/O-Test fehlgeschlagen: Geschriebene und gelesene Daten sind nicht identisch.");
            }

            var decimalMegabytes = testBytes / 1000d / 1000d;
            var writeSeconds = Math.Max(benchmark.WriteSeconds, 0.001d);
            var readSeconds = Math.Max(benchmark.ReadSeconds, 0.001d);
            var writeMbPerSecond = decimalMegabytes / writeSeconds;
            var readMbPerSecond = decimalMegabytes / readSeconds;

            if (writeMbPerSecond < minMegabytesPerSecond || readMbPerSecond < minMegabytesPerSecond)
            {
                return new ReadWriteTestResult(
                    true,
                    false,
                    $"zu langsam: W {FormatSpeed(writeMbPerSecond)} / R {FormatSpeed(readMbPerSecond)} MB/s",
                    "Read/Write-Test fehlgeschlagen: " +
                    $"{testMegabytes} MB wurden per Direct I/O geschrieben und per SHA-256 verifiziert, aber die Geschwindigkeit ist zu niedrig. " +
                    $"Schreiben {FormatSpeed(writeMbPerSecond, 1)} MB/s, Lesen {FormatSpeed(readMbPerSecond, 1)} MB/s, Mindestwert {FormatSpeed(minMegabytesPerSecond)} MB/s.");
            }

            var pathText = testRoot.Length > 60 ? testRoot[..57] + "..." : testRoot;
            return new ReadWriteTestResult(
                true,
                true,
                $"W {FormatSpeed(writeMbPerSecond)} / R {FormatSpeed(readMbPerSecond)} MB/s",
                "Read/Write-Test bestanden: " +
                (string.IsNullOrWhiteSpace(preparationNote) ? string.Empty : preparationNote + " ") +
                $"{testMegabytes} MB per Direct I/O geschrieben, zurückgelesen und per SHA-256 geprüft. " +
                $"Schreiben {FormatSpeed(writeMbPerSecond, 1)} MB/s, Lesen {FormatSpeed(readMbPerSecond, 1)} MB/s, Mindestwert {FormatSpeed(minMegabytesPerSecond)} MB/s. " +
                "Testdatei wurde gelöscht.");
        }
        catch (Exception ex)
        {
            return new ReadWriteTestResult(true, false, "Fehler", "Read/Write-Test fehlgeschlagen auf " + testRoot + ": " + ex.Message);
        }
        finally
        {
            try
            {
                if (File.Exists(filePath))
                    File.Delete(filePath);
            }
            catch
            {
                // Wenn das Löschen fehlschlägt, bleibt maximal die aktuell gewählte Testdatei zurück.
            }
        }
    }

    private static byte[] CreateTestPatternBuffer(int length)
    {
        var buffer = new byte[length];
        for (var i = 0; i < buffer.Length; i++)
            buffer[i] = (byte)((i * 31 + 17) & 0xFF);
        return buffer;
    }

    private static void StampTestBlock(byte[] buffer, int blockIndex, int validBytes)
    {
        var stamp = BitConverter.GetBytes(blockIndex);
        Buffer.BlockCopy(stamp, 0, buffer, 0, stamp.Length);
        stamp = BitConverter.GetBytes(validBytes);
        Buffer.BlockCopy(stamp, 0, buffer, 4, stamp.Length);
    }

    private static async Task<bool> WaitForWritablePathAsync(string path, int timeoutMs)
    {
        var deadline = DateTime.UtcNow.AddMilliseconds(timeoutMs);
        var normalized = NormalizeTestRoot(path);

        while (DateTime.UtcNow <= deadline)
        {
            try
            {
                Directory.CreateDirectory(normalized);
                var probe = Path.Combine(normalized, $".nvme_probe_{Guid.NewGuid():N}.tmp");
                await File.WriteAllTextAsync(probe, "probe", Encoding.ASCII);
                File.Delete(probe);
                return true;
            }
            catch
            {
                await Task.Delay(150);
            }
        }

        return false;
    }

    private static string NormalizeTestRoot(string path)
    {
        path = path.Trim().Trim('"');

        if (path.Length == 2 && path[1] == ':')
            return path + @"\";

        if (!path.EndsWith(Path.DirectorySeparatorChar) && !path.EndsWith(Path.AltDirectorySeparatorChar))
            path += Path.DirectorySeparatorChar;

        return path;
    }

    private void ConfigureReadWriteSizeCheckBox(CheckBox checkBox, string label, int megabytes)
    {
        checkBox.Text = label;
        checkBox.Tag = megabytes;
        checkBox.AutoSize = true;
        checkBox.Margin = new Padding(0, 7, 26, 0);
        checkBox.CheckedChanged += (_, _) =>
        {
            if (_loadingSettings)
                return;

            if (!checkBox.Checked)
            {
                if (!_rwSize128.Checked && !_rwSize256.Checked && !_rwSize512.Checked)
                    SelectReadWriteTestSize(megabytes);
                return;
            }

            SelectReadWriteTestSize(megabytes);
        };
    }

    private void RestoreReadWriteTestSizeSelection()
    {
        var savedSize = _appSettings.ReadWriteTestMB;
        if (savedSize is not (128 or 256 or 512))
            savedSize = 256;

        SelectReadWriteTestSize(savedSize, save: false);
    }

    private void SelectReadWriteTestSize(int megabytes, bool save = true)
    {
        if (megabytes is not (128 or 256 or 512))
            megabytes = 256;

        var oldLoading = _loadingSettings;
        _loadingSettings = true;
        _rwSize128.Checked = megabytes == 128;
        _rwSize256.Checked = megabytes == 256;
        _rwSize512.Checked = megabytes == 512;
        _loadingSettings = oldLoading;

        if (!save || oldLoading)
            return;

        _appSettings.ReadWriteTestMB = megabytes;
        _appSettings.Save();
    }

    private int SelectedReadWriteTestMegabytes()
    {
        if (_rwSize512.Checked)
            return 512;

        if (_rwSize256.Checked)
            return 256;

        return 128;
    }

    private void RestoreLastSelectedSize()
    {
        var savedSize = _appSettings.ExpectedSizeGB;
        if (savedSize <= 0)
            savedSize = 128;

        for (var i = 0; i < _sizeDropDown.Items.Count; i++)
        {
            if (_sizeDropDown.Items[i] is SizeOption option && Math.Abs(option.Gigabytes - savedSize) < 0.001)
            {
                _sizeDropDown.SelectedIndex = i;
                return;
            }
        }

        _sizeDropDown.SelectedIndex = 0;
    }

    private void SaveCurrentSizeSelection()
    {
        if (_loadingSettings)
            return;

        if (_sizeDropDown.SelectedItem is not SizeOption option)
            return;

        _appSettings.ExpectedSizeGB = option.Gigabytes;
        _appSettings.Save();
    }

    private void SaveCurrentMinimumSpeedSelection()
    {
        if (_loadingSettings)
            return;

        _appSettings.MinReadWriteSpeedMBs = (int)_minSpeed.Value;
        _appSettings.Save();
    }

    private void RestoreMaximumWearSelection()
    {
        var savedWear = _appSettings.MaxWearPercent;
        if (savedWear < 10 || savedWear > 45 || savedWear % 5 != 0)
            savedWear = 10;

        for (var i = 0; i < _maxWearDropDown.Items.Count; i++)
        {
            if (_maxWearDropDown.Items[i] is WearOption option && option.Percent == savedWear)
            {
                _maxWearDropDown.SelectedIndex = i;
                return;
            }
        }

        _maxWearDropDown.SelectedIndex = 0;
    }

    private void SaveCurrentMaximumWearSelection()
    {
        if (_loadingSettings)
            return;

        if (_maxWearDropDown.SelectedItem is not WearOption option)
            return;

        _appSettings.MaxWearPercent = option.Percent;
        _appSettings.Save();
    }

    private int SelectedMaximumWearPercent()
    {
        if (_maxWearDropDown.SelectedItem is WearOption option)
            return option.Percent;

        return Math.Clamp(_appSettings.MaxWearPercent, 10, 45);
    }

    private void ConfigureThresholdDropDown(ComboBox dropDown, IEnumerable<int> values, string suffix, int selectedValue)
    {
        dropDown.DropDownStyle = ComboBoxStyle.DropDownList;
        dropDown.Dock = DockStyle.Fill;
        foreach (var value in values.Distinct().OrderBy(v => v))
            dropDown.Items.Add(new ThresholdOption($"{value}{suffix}", value));

        SelectThresholdValue(dropDown, selectedValue);
    }

    private static void SelectThresholdValue(ComboBox dropDown, int selectedValue)
    {
        for (var i = 0; i < dropDown.Items.Count; i++)
        {
            if (dropDown.Items[i] is ThresholdOption option && option.Value == selectedValue)
            {
                dropDown.SelectedIndex = i;
                return;
            }
        }

        if (dropDown.Items.Count > 0)
            dropDown.SelectedIndex = 0;
    }

    private void SaveCurrentSmartLimitSelection()
    {
        if (_loadingSettings)
            return;

        _appSettings.MinSparePercent = SelectedMinimumSparePercent();
        _appSettings.MaxTemperatureC = SelectedMaximumTemperatureC();
        _appSettings.MaxWriteErrorsTotal = SelectedMaximumWriteErrorsTotal();
        _appSettings.Save();
    }

    private int SelectedMinimumSparePercent() =>
        _minSpareDropDown.SelectedItem is ThresholdOption option ? option.Value : Math.Clamp(_appSettings.MinSparePercent, 70, 100);

    private int SelectedMaximumTemperatureC() =>
        _maxTemperatureDropDown.SelectedItem is ThresholdOption option ? option.Value : Math.Clamp(_appSettings.MaxTemperatureC, 50, 90);

    private int SelectedMaximumWriteErrorsTotal() =>
        _maxWriteErrDropDown.SelectedItem is ThresholdOption option ? option.Value : Math.Max(10, _appSettings.MaxWriteErrorsTotal);

    private void OpenSettingsDialog()
    {
        using var dialog = new SettingsDialog(_appSettings);
        if (dialog.ShowDialog(this) != DialogResult.OK)
            return;

        _appSettings.MinSparePercent = dialog.MinSparePercent;
        _appSettings.MaxTemperatureC = dialog.MaxTemperatureC;
        _appSettings.MaxWriteErrorsTotal = dialog.MaxWriteErrorsTotal;
        _appSettings.LogRetentionDays = dialog.LogRetentionDays;
        _appSettings.Save();

        ApplySettingsToControls();
        CsvResultExporter.CleanupOldDailyLogs(_appSettings.LogRetentionDays);
    }

    private void ApplySettingsToControls()
    {
        var oldLoading = _loadingSettings;
        _loadingSettings = true;
        try
        {
            SelectThresholdValue(_minSpareDropDown, _appSettings.MinSparePercent);
            SelectThresholdValue(_maxTemperatureDropDown, _appSettings.MaxTemperatureC);
            SelectThresholdValue(_maxWriteErrDropDown, _appSettings.MaxWriteErrorsTotal);
            RestoreMaximumWearSelection();
            _minSpeed.Value = ClampDecimal(_appSettings.MinReadWriteSpeedMBs, _minSpeed.Minimum, _minSpeed.Maximum);
            SelectReadWriteTestSize(_appSettings.ReadWriteTestMB, save: false);
        }
        finally
        {
            _loadingSettings = oldLoading;
        }
    }

    private static decimal ClampDecimal(int value, decimal minimum, decimal maximum)
    {
        if (value < minimum)
            return minimum;

        if (value > maximum)
            return maximum;

        return value;
    }

    private void ApplyHistoryColumnLayout()
    {
        _restoringHistoryColumnLayout = true;
        try
        {
            var defaults = DefaultHistoryColumnWidths();
            foreach (DataGridViewColumn column in _history.Columns)
            {
                column.Resizable = DataGridViewTriState.True;
                column.MinimumWidth = 35;
                column.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

                var width = defaults.TryGetValue(column.Name, out var defaultWidth) ? defaultWidth : Math.Max(60, column.Width);
                if (_appSettings.HistoryColumnWidths.TryGetValue(column.Name, out var savedWidth))
                    width = savedWidth;

                column.Width = Math.Clamp(width, 35, 650);
            }
        }
        finally
        {
            _restoringHistoryColumnLayout = false;
        }
    }

    private void SaveHistoryColumnLayout()
    {
        if (_restoringHistoryColumnLayout || _loadingSettings)
            return;

        _appSettings.HistoryColumnWidths = _history.Columns
            .Cast<DataGridViewColumn>()
            .ToDictionary(column => column.Name, column => column.Width, StringComparer.OrdinalIgnoreCase);
        _appSettings.Save();
    }

    private static Dictionary<string, int> DefaultHistoryColumnWidths() => new(StringComparer.OrdinalIgnoreCase)
    {
        ["Time"] = 80,
        ["Result"] = 105,
        ["Name"] = 250,
        ["Serial"] = 165,
        ["Size"] = 120,
        ["Health"] = 145,
        ["Smart"] = 80,
        ["PowerOnHours"] = 90,
        ["ReadWrite"] = 220,
    };

    private string BuildDetails(DiskInfo disk, SizeOption sizeOption, bool sizeOk, bool healthOk, bool smartOk, ReadWriteTestResult readWrite, bool passed, List<string> notes)
    {
        var left = new List<string>
        {
            "TEST",
            $"Zeit: {DateTime.Now:yyyy-MM-dd HH:mm:ss}",
            $"Ergebnis: {(passed ? "BESTANDEN" : "FEHLER")}",
            "",
            "LAUFWERK",
            $"Name: {disk.FriendlyName}",
            $"Seriennummer: {disk.SerialNumber}",
            $"Disk-Nr.: {(disk.DiskNumber.HasValue ? disk.DiskNumber.Value.ToString() : "n/a")}",
            $"UniqueId: {disk.UniqueId}",
            $"Bus/Media: {disk.BusType} / {disk.MediaType}",
            $"Volumes: {DriveLettersToText(disk.DriveLetters)}",
            $"Größe: {FormatGb(disk.SizeBytes)} / {FormatGib(disk.SizeBytes)}",
            $"Soll: {sizeOption.Gigabytes:N0} GB ± {_tolerance.Value:N1}%"
        };

        var middle = new List<string>
        {
            "PRÜFUNGEN",
            $"Größe OK: {BoolToJaNein(sizeOk)}",
            $"Health OK: {BoolToJaNein(healthOk)}",
            $"SMART OK: {BoolToJaNein(smartOk)}",
            $"R/W OK: {BoolToJaNein(readWrite.Passed)}",
            $"Min. Spare: {SelectedMinimumSparePercent()} %",
            $"Max. Temp: {SelectedMaximumTemperatureC()} °C",
            $"Max. WriteErr: {SelectedMaximumWriteErrorsTotal()}",
            "",
            "HEALTH / SMART",
            $"HealthStatus: {disk.HealthStatus}",
            $"Anzeige: {GetHealthDisplay(disk)}",
            $"Operation: {disk.OperationalStatus}",
            $"SMART verfügbar: {BoolToJaNein(disk.SmartAvailable)}",
            $"SMART Passed: {BoolToText(disk.SmartStatusPassed)}",
            $"Critical: {NullableToText(disk.CriticalWarning)}",
            $"Temp: {NullableToText(disk.Temperature)} °C"
        };

        var right = new List<string>
        {
            "WEAR / FEHLER",
            $"Max. Wear: {SelectedMaximumWearPercent()} %",
            $"Wear: {NullableToText(disk.Wear)} %",
            $"Life: {NullableToText(disk.LifeRemaining)} %",
            $"Spare: {NullableToText(disk.AvailableSpare)} %",
            $"MediaErr: {NullableToText(disk.ReadErrorsTotal)}",
            $"WriteErr: {NullableToText(disk.WriteErrorsTotal)}",
            $"Realloc: {NullableToText(disk.ReallocatedSectors)}",
            $"Pending: {NullableToText(disk.PendingSectors)}",
            $"Uncorr: {NullableToText(disk.UncorrectableErrors)}",
            $"CRC: {NullableToText(disk.CrcErrors)}",
            $"Power On: {FormatPowerOnHours(disk.PowerOnHours)}",
            "",
            "READ / WRITE",
            readWrite.Summary
        };

        var sb = new StringBuilder();
        sb.AppendLine(FormatDetailsColumns(left, middle, right, 42, 42, 42));

        if (!string.IsNullOrWhiteSpace(readWrite.Details))
        {
            sb.AppendLine();
            sb.AppendLine("Read/Write-Details:");
            sb.AppendLine(IndentWrapped(readWrite.Details, 2, 132));
        }

        var distinctNotes = notes.Distinct().Where(x => !string.IsNullOrWhiteSpace(x)).ToList();
        if (distinctNotes.Count > 0)
        {
            sb.AppendLine();
            sb.AppendLine("Hinweise:");
            foreach (var note in distinctNotes)
                sb.AppendLine("- " + note);
        }

        return sb.ToString();
    }

    private static string FormatDetailsColumns(IReadOnlyList<string> left, IReadOnlyList<string> middle, IReadOnlyList<string> right, int leftWidth, int middleWidth, int rightWidth)
    {
        var leftLines = WrapColumn(left, leftWidth).ToList();
        var middleLines = WrapColumn(middle, middleWidth).ToList();
        var rightLines = WrapColumn(right, rightWidth).ToList();
        var rows = Math.Max(leftLines.Count, Math.Max(middleLines.Count, rightLines.Count));

        var sb = new StringBuilder();
        for (var i = 0; i < rows; i++)
        {
            var l = i < leftLines.Count ? leftLines[i] : string.Empty;
            var m = i < middleLines.Count ? middleLines[i] : string.Empty;
            var r = i < rightLines.Count ? rightLines[i] : string.Empty;
            sb.Append(PadColumn(l, leftWidth));
            sb.Append("  │  ");
            sb.Append(PadColumn(m, middleWidth));
            sb.Append("  │  ");
            sb.AppendLine(PadColumn(r, rightWidth));
        }

        return sb.ToString().TrimEnd();
    }

    private static IEnumerable<string> WrapColumn(IEnumerable<string> lines, int width)
    {
        foreach (var line in lines)
        {
            if (string.IsNullOrEmpty(line))
            {
                yield return string.Empty;
                continue;
            }

            var text = line.TrimEnd();
            while (text.Length > width)
            {
                var cut = text.LastIndexOf(' ', Math.Min(width, text.Length - 1));
                if (cut < 12)
                    cut = width;

                yield return text[..cut].TrimEnd();
                text = text[cut..].TrimStart();
            }

            yield return text;
        }
    }

    private static string PadColumn(string value, int width)
    {
        if (value.Length > width)
            return value[..width];

        return value.PadRight(width);
    }

    private static string IndentWrapped(string text, int indentSpaces, int width)
    {
        var indent = new string(' ', indentSpaces);
        var wrapped = WrapColumn(text.Replace("\r", string.Empty).Split('\n'), Math.Max(20, width - indentSpaces));
        return string.Join(Environment.NewLine, wrapped.Select(line => indent + line));
    }

    private static string BoolToJaNein(bool value) => value ? "JA" : "NEIN";

    private void AddResult(CheckResult result)
    {
        var timestamp = DateTime.Now;
        var resultText = result.Passed ? "BESTANDEN" : "FEHLER";
        var sizeText = FormatGb(result.Disk.SizeBytes);
        var healthText = GetHealthDisplay(result.Disk);
        var hoursText = FormatPowerOnHours(result.Disk.PowerOnHours);

        _history.Rows.Insert(0,
            timestamp.ToString("HH:mm:ss"),
            resultText,
            result.Disk.FriendlyName,
            result.Disk.SerialNumber,
            sizeText,
            healthText,
            result.SmartSummary,
            hoursText,
            result.ReadWriteSummary);

        var row = _history.Rows[0];
        var backColor = result.Passed ? Color.FromArgb(220, 255, 220) : Color.FromArgb(255, 225, 225);
        row.DefaultCellStyle.BackColor = backColor;
        row.DefaultCellStyle.SelectionBackColor = backColor;
        row.DefaultCellStyle.SelectionForeColor = _history.DefaultCellStyle.ForeColor;
        row.Selected = false;
        _history.ClearSelection();

        var snapshot = new ExportResultSnapshot(
            timestamp,
            resultText,
            result.Disk.FriendlyName,
            result.Disk.SerialNumber,
            sizeText,
            healthText,
            result.SmartSummary,
            hoursText,
            result.ReadWriteSummary,
            result.Details);

        _exportResults.Insert(0, snapshot);
        CsvResultExporter.AppendDailyLog(snapshot);

        _details.Text = result.Details;
    }

    private void ExportPdfOnClick(object? sender, EventArgs e)
    {
        try
        {
            var option = _exportFilterDropDown.SelectedItem as ExportFilterOption ?? new ExportFilterOption("Alle", null);
            var rows = _exportResults
                .Where(r => option.ResultFilter == null || string.Equals(r.Result, option.ResultFilter, StringComparison.OrdinalIgnoreCase))
                .ToList();

            if (rows.Count == 0)
            {
                MessageBox.Show(this, "Für die aktuelle Export-Auswahl sind keine Prüfergebnisse vorhanden.", "PDF Export", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            using var dialog = new SaveFileDialog
            {
                Title = "Prüfergebnisse als PDF speichern",
                Filter = "PDF-Datei (*.pdf)|*.pdf",
                DefaultExt = "pdf",
                AddExtension = true,
                OverwritePrompt = true,
                FileName = BuildDefaultPdfFileName(option)
            };

            if (dialog.ShowDialog(this) != DialogResult.OK)
                return;

            PdfResultExporter.Export(dialog.FileName, rows, option.Label);
            MessageBox.Show(this, $"PDF wurde gespeichert:\n{dialog.FileName}", "PDF Export", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "PDF Export fehlgeschlagen:\n" + ex.Message, "PDF Export", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void ExportCsvOnClick(object? sender, EventArgs e)
    {
        try
        {
            var option = _exportFilterDropDown.SelectedItem as ExportFilterOption ?? new ExportFilterOption("Alle", null);
            var rows = _exportResults
                .Where(r => option.ResultFilter == null || string.Equals(r.Result, option.ResultFilter, StringComparison.OrdinalIgnoreCase))
                .ToList();

            if (rows.Count == 0)
            {
                MessageBox.Show(this, "Für die aktuelle Export-Auswahl sind keine Prüfergebnisse vorhanden.", "CSV Export", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            using var dialog = new SaveFileDialog
            {
                Title = "Prüfergebnisse als CSV speichern",
                Filter = "CSV-Datei (*.csv)|*.csv",
                DefaultExt = "csv",
                AddExtension = true,
                OverwritePrompt = true,
                FileName = BuildDefaultCsvFileName(option)
            };

            if (dialog.ShowDialog(this) != DialogResult.OK)
                return;

            CsvResultExporter.Export(dialog.FileName, rows);
            MessageBox.Show(this, $"CSV wurde gespeichert:\n{dialog.FileName}", "CSV Export", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "CSV Export fehlgeschlagen:\n" + ex.Message, "CSV Export", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private static string BuildDefaultPdfFileName(ExportFilterOption option)
    {
        var filter = string.IsNullOrWhiteSpace(option.ResultFilter) ? "Alle" : option.ResultFilter;
        foreach (var ch in Path.GetInvalidFileNameChars())
            filter = filter.Replace(ch, '_');

        return $"NvmeUsbQuickCheck_{filter}_{DateTime.Now:yyyyMMdd_HHmmss}.pdf";
    }

    private static string BuildDefaultCsvFileName(ExportFilterOption option)
    {
        var filter = string.IsNullOrWhiteSpace(option.ResultFilter) ? "Alle" : option.ResultFilter;
        foreach (var ch in Path.GetInvalidFileNameChars())
            filter = filter.Replace(ch, '_');

        return $"NvmeUsbQuickCheck_{filter}_{DateTime.Now:yyyyMMdd_HHmmss}.csv";
    }

    private void ToggleRunning()
    {
        _isRunning = !_isRunning;
        _startStop.Text = _isRunning ? "Stoppen" : "Starten";
        if (_isRunning)
        {
            _currentlyPresent.Clear();
            SetStatus("Überwachung läuft. USB-NVMe einstecken.", Color.DodgerBlue);
        }
        else
        {
            SetStatus("Überwachung gestoppt.", Color.DimGray);
        }
    }

    private void SetStatus(string text, Color color)
    {
        _status.Text = text;
        _status.ForeColor = Color.White;
        _status.BackColor = color;
    }

    private static string CleanDisplayText(string? value)
    {
        if (string.IsNullOrEmpty(value))
            return string.Empty;

        var sb = new StringBuilder(value.Length);
        foreach (var ch in value)
        {
            if (!char.IsControl(ch))
                sb.Append(ch);
        }

        return sb.ToString().Trim();
    }

    private static bool IsWindowsHealthOk(string? healthStatus, string? operationalStatus)
    {
        // v60: Nach dem StabilityFix kommt OperationalStatus aus Get-Disk.
        // Get-Disk meldet bei guten Datenträgern häufig "Online" statt "OK".
        // Die alte Prüfung akzeptierte nur "OK" und hat dadurch fast jedes Laufwerk als Fehler markiert.
        var health = CleanDisplayText(healthStatus);
        var operational = CleanDisplayText(operationalStatus);

        var healthOk = string.IsNullOrWhiteSpace(health)
                       || health.Equals("Healthy", StringComparison.OrdinalIgnoreCase)
                       || health.Equals("OK", StringComparison.OrdinalIgnoreCase)
                       || health.Equals("Unknown", StringComparison.OrdinalIgnoreCase);

        var operationalOk = string.IsNullOrWhiteSpace(operational)
                            || operational.Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries)
                                .Any(x => x.Equals("OK", StringComparison.OrdinalIgnoreCase)
                                          || x.Equals("Online", StringComparison.OrdinalIgnoreCase)
                                          || x.Equals("Healthy", StringComparison.OrdinalIgnoreCase)
                                          || x.Equals("In Service", StringComparison.OrdinalIgnoreCase));

        var explicitBad = new[]
        {
            "Unhealthy", "Warning", "Degraded", "Lost Communication", "No Contact", "Failed", "Offline", "Pred Fail"
        };

        if (explicitBad.Any(x => health.Contains(x, StringComparison.OrdinalIgnoreCase)
                                 || operational.Contains(x, StringComparison.OrdinalIgnoreCase)))
            return false;

        return healthOk && operationalOk;
    }

    private static bool ContainsOk(string? value)
    {
        return !string.IsNullOrWhiteSpace(value)
               && value.Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries)
                   .Any(x => string.Equals(x, "OK", StringComparison.OrdinalIgnoreCase));
    }

    private static bool IsAdministrator()
    {
        using var identity = WindowsIdentity.GetCurrent();
        var principal = new WindowsPrincipal(identity);
        return principal.IsInRole(WindowsBuiltInRole.Administrator);
    }

    private static string FormatGb(ulong bytes) => $"{bytes / 1000d / 1000d / 1000d:N1} GB";
    private static string FormatGib(ulong bytes) => $"{bytes / 1024d / 1024d / 1024d:N1} GiB";
    private static string FormatSpeed(double value, int decimals = 0)
    {
        var format = decimals <= 0 ? "0" : "0." + new string('0', decimals);
        // Keine Tausenderpunkte in der Ergebnisliste: 3170 statt 3.170 MB/s.
        return value.ToString(format, CultureInfo.InvariantCulture);
    }
    private static string NullableToText(long? value) => value.HasValue ? value.Value.ToString() : "n/a";
    private static string FormatPowerOnHours(long? hours) => hours.HasValue ? $"{hours.Value:N0} h" : "n/a";
    private static string BoolToText(bool? value) => value.HasValue ? (value.Value ? "JA" : "NEIN") : "n/a";
    private static IEnumerable<string> SplitDriveLetters(string? letters) =>
        string.IsNullOrWhiteSpace(letters)
            ? Array.Empty<string>()
            : letters.Split(new[] { ',', ';', ' ' }, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                .Select(x => x.Trim().TrimEnd(':'))
                .Where(x => x.Length == 1 && char.IsLetter(x[0]));

    private static string DriveLettersToText(string? letters)
    {
        var normalized = SplitDriveLetters(letters).Select(x => x + ":").ToArray();
        return normalized.Length == 0 ? "n/a" : string.Join(", ", normalized);
    }

    private static string GetHealthDisplay(DiskInfo disk)
    {
        if (!string.IsNullOrWhiteSpace(disk.WearLevelText))
            return disk.WearLevelText;

        if (disk.Wear.HasValue)
            return $"Wear {disk.Wear.Value}%";

        if (disk.LifeRemaining.HasValue)
            return $"Life {disk.LifeRemaining.Value}%";

        if (disk.AvailableSpare.HasValue)
            return $"Spare {disk.AvailableSpare.Value}%";

        return string.IsNullOrWhiteSpace(disk.HealthStatus) ? "n/a" : disk.HealthStatus;
    }

    private static void PlayPassSound()
    {
        Task.Run(() =>
        {
            try
            {
                Console.Beep(1200, 120);
                Thread.Sleep(60);
                Console.Beep(1600, 120);
            }
            catch
            {
                SystemSounds.Asterisk.Play();
            }
        });
    }

    private static void PlayFailSound()
    {
        Task.Run(() =>
        {
            try
            {
                Console.Beep(450, 350);
                Thread.Sleep(80);
                Console.Beep(300, 350);
            }
            catch
            {
                SystemSounds.Hand.Play();
            }
        });
    }

    private sealed record DirectIoResult(double WriteSeconds, double ReadSeconds, int TotalRead, bool HashOk);

    private static class DirectIoBenchmark
    {
        private const int BufferBytes = 4 * 1024 * 1024;
        private const uint GenericRead = 0x80000000;
        private const uint GenericWrite = 0x40000000;
        private const uint FileShareRead = 0x00000001;
        private const uint FileShareWrite = 0x00000002;
        private const uint CreateAlways = 2;
        private const uint OpenExisting = 3;
        private const uint FileAttributeNormal = 0x00000080;
        private const uint FileFlagNoBuffering = 0x20000000;
        // FILE_FLAG_WRITE_THROUGH wurde entfernt: Bei einigen USB-NVMe-Bridges kann es den Storage-Stack blockieren.
        private const uint FileFlagSequentialScan = 0x08000000;
        private const uint MemCommit = 0x00001000;
        private const uint MemReserve = 0x00002000;
        private const uint MemRelease = 0x00008000;
        private const uint PageReadWrite = 0x04;

        public static DirectIoResult Run(string filePath, int testBytes)
        {
            if (testBytes % BufferBytes != 0)
                throw new InvalidOperationException("Direct I/O erfordert eine Testgröße als Vielfaches der Blockgröße.");

            var writePtr = IntPtr.Zero;
            var readPtr = IntPtr.Zero;

            try
            {
                writePtr = VirtualAlloc(IntPtr.Zero, new UIntPtr(BufferBytes), MemCommit | MemReserve, PageReadWrite);
                readPtr = VirtualAlloc(IntPtr.Zero, new UIntPtr(BufferBytes), MemCommit | MemReserve, PageReadWrite);
                if (writePtr == IntPtr.Zero || readPtr == IntPtr.Zero)
                    throw LastWin32Exception("VirtualAlloc");

                var writeBuffer = CreateTestPatternBuffer(BufferBytes);
                var readBuffer = new byte[BufferBytes];
                var writeStopwatch = new Stopwatch();
                var readStopwatch = new Stopwatch();
                var totalRead = 0;
                byte[] expectedHash;
                using (var expectedHasher = IncrementalHash.CreateHash(HashAlgorithmName.SHA256))
                using (var handle = CreateDirectWriteHandle(filePath))
                {
                    var remaining = testBytes;
                    var blockIndex = 0;
                    while (remaining > 0)
                    {
                        var chunk = Math.Min(BufferBytes, remaining);
                        StampTestBlock(writeBuffer, blockIndex, chunk);
                        expectedHasher.AppendData(writeBuffer, 0, chunk);
                        Marshal.Copy(writeBuffer, 0, writePtr, chunk);

                        writeStopwatch.Start();
                        if (!WriteFile(handle, writePtr, (uint)chunk, out var written, IntPtr.Zero))
                            throw LastWin32Exception("WriteFile");
                        writeStopwatch.Stop();

                        if (written != chunk)
                            throw new IOException($"Direct-I/O-Schreibfehler: Erwartet {chunk:N0} Bytes, geschrieben {written:N0} Bytes.");

                        remaining -= chunk;
                        blockIndex++;
                    }

                    expectedHash = expectedHasher.GetHashAndReset();
                }

                byte[] actualHash;
                using (var actualHasher = IncrementalHash.CreateHash(HashAlgorithmName.SHA256))
                using (var handle = CreateDirectReadHandle(filePath))
                {
                    while (totalRead < testBytes)
                    {
                        var wanted = Math.Min(BufferBytes, testBytes - totalRead);

                        readStopwatch.Start();
                        if (!ReadFile(handle, readPtr, (uint)wanted, out var read, IntPtr.Zero))
                            throw LastWin32Exception("ReadFile");
                        readStopwatch.Stop();

                        if (read == 0)
                            break;

                        Marshal.Copy(readPtr, readBuffer, 0, (int)read);
                        actualHasher.AppendData(readBuffer, 0, (int)read);
                        totalRead += (int)read;
                    }

                    actualHash = actualHasher.GetHashAndReset();
                }

                return new DirectIoResult(
                    writeStopwatch.Elapsed.TotalSeconds,
                    readStopwatch.Elapsed.TotalSeconds,
                    totalRead,
                    expectedHash.SequenceEqual(actualHash));
            }
            finally
            {
                if (writePtr != IntPtr.Zero)
                    VirtualFree(writePtr, UIntPtr.Zero, MemRelease);
                if (readPtr != IntPtr.Zero)
                    VirtualFree(readPtr, UIntPtr.Zero, MemRelease);
            }
        }

        private static SafeFileHandle CreateDirectWriteHandle(string path)
        {
            var flags = FileAttributeNormal | FileFlagNoBuffering | FileFlagSequentialScan;
            var handle = CreateFileW(path, GenericWrite, FileShareRead, IntPtr.Zero, CreateAlways, flags, IntPtr.Zero);
            if (handle.IsInvalid)
                throw LastWin32Exception("CreateFileW(write, direct)");
            return handle;
        }

        private static SafeFileHandle CreateDirectReadHandle(string path)
        {
            var flags = FileAttributeNormal | FileFlagNoBuffering | FileFlagSequentialScan;
            var handle = CreateFileW(path, GenericRead, FileShareRead | FileShareWrite, IntPtr.Zero, OpenExisting, flags, IntPtr.Zero);
            if (handle.IsInvalid)
                throw LastWin32Exception("CreateFileW(read, direct)");
            return handle;
        }

        private static Exception LastWin32Exception(string operation)
        {
            var error = Marshal.GetLastWin32Error();
            return new IOException($"{operation} fehlgeschlagen: {new Win32Exception(error).Message} (Win32 {error}).");
        }

        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        private static extern SafeFileHandle CreateFileW(
            string lpFileName,
            uint dwDesiredAccess,
            uint dwShareMode,
            IntPtr lpSecurityAttributes,
            uint dwCreationDisposition,
            uint dwFlagsAndAttributes,
            IntPtr hTemplateFile);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool ReadFile(
            SafeFileHandle hFile,
            IntPtr lpBuffer,
            uint nNumberOfBytesToRead,
            out uint lpNumberOfBytesRead,
            IntPtr lpOverlapped);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool WriteFile(
            SafeFileHandle hFile,
            IntPtr lpBuffer,
            uint nNumberOfBytesToWrite,
            out uint lpNumberOfBytesWritten,
            IntPtr lpOverlapped);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr VirtualAlloc(
            IntPtr lpAddress,
            UIntPtr dwSize,
            uint flAllocationType,
            uint flProtect);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool VirtualFree(
            IntPtr lpAddress,
            UIntPtr dwSize,
            uint dwFreeType);
    }
}

internal sealed class SizeOption
{
    public SizeOption(string label, double gigabytes)
    {
        Label = label;
        Gigabytes = gigabytes;
    }

    public string Label { get; }
    public double Gigabytes { get; }
    public override string ToString() => Label;
}

internal sealed class WearOption
{
    public WearOption(string label, int percent)
    {
        Label = label;
        Percent = percent;
    }

    public string Label { get; }
    public int Percent { get; }
    public override string ToString() => Label;
}

internal sealed class ThresholdOption
{
    public ThresholdOption(string label, int value)
    {
        Label = label;
        Value = value;
    }

    public string Label { get; }
    public int Value { get; }
    public override string ToString() => Label;
}

internal sealed record ExportResultSnapshot(
    DateTime Timestamp,
    string Result,
    string Name,
    string SerialNumber,
    string Size,
    string Health,
    string Smart,
    string Hours,
    string ReadWrite,
    string Details);

internal sealed class ExportFilterOption
{
    public ExportFilterOption(string label, string? resultFilter)
    {
        Label = label;
        ResultFilter = resultFilter;
    }

    public string Label { get; }
    public string? ResultFilter { get; }
    public override string ToString() => Label;
}

internal sealed class SettingsDialog : Form
{
    private readonly ComboBox _minSpare = new();
    private readonly ComboBox _maxTemperature = new();
    private readonly NumericUpDown _maxWriteErr = new();
    private readonly NumericUpDown _logRetention = new();

    public SettingsDialog(AppSettings settings)
    {
        Text = "Einstellungen";
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        StartPosition = FormStartPosition.CenterParent;
        ClientSize = new Size(420, 218);
        Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);

        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 5,
            Padding = new Padding(14),
        };
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 180));
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        for (var i = 0; i < 4; i++)
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 34));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        Controls.Add(root);

        root.Controls.Add(new Label { Text = "Min. Spare", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, 0);
        ConfigureCombo(_minSpare, Enumerable.Range(14, 7).Select(i => i * 5), "%", settings.MinSparePercent);
        root.Controls.Add(_minSpare, 1, 0);

        root.Controls.Add(new Label { Text = "Max. Temperatur", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, 1);
        ConfigureCombo(_maxTemperature, Enumerable.Range(10, 9).Select(i => i * 5), " °C", settings.MaxTemperatureC);
        root.Controls.Add(_maxTemperature, 1, 1);

        root.Controls.Add(new Label { Text = "Max. WriteErr", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, 2);
        _maxWriteErr.Minimum = 0;
        _maxWriteErr.Maximum = 1000000;
        _maxWriteErr.DecimalPlaces = 0;
        _maxWriteErr.Increment = 1;
        _maxWriteErr.Value = Math.Clamp(settings.MaxWriteErrorsTotal, 0, 1000000);
        _maxWriteErr.Dock = DockStyle.Left;
        _maxWriteErr.Width = 120;
        root.Controls.Add(_maxWriteErr, 1, 2);

        root.Controls.Add(new Label { Text = "Logs behalten", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, 3);
        var logPanel = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false,
            Margin = new Padding(0),
            Padding = new Padding(0),
        };
        _logRetention.Minimum = 1;
        _logRetention.Maximum = 3650;
        _logRetention.DecimalPlaces = 0;
        _logRetention.Increment = 10;
        _logRetention.Value = Math.Clamp(settings.LogRetentionDays, 1, 3650);
        _logRetention.Dock = DockStyle.Left;
        _logRetention.Width = 90;
        logPanel.Controls.Add(_logRetention);
        logPanel.Controls.Add(new Label { Text = "Tage", AutoSize = true, Margin = new Padding(8, 7, 0, 0) });
        root.Controls.Add(logPanel, 1, 3);

        var buttons = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.RightToLeft,
        };
        var ok = new Button { Text = "OK", DialogResult = DialogResult.OK, Width = 90 };
        var cancel = new Button { Text = "Abbrechen", DialogResult = DialogResult.Cancel, Width = 100 };
        buttons.Controls.Add(ok);
        buttons.Controls.Add(cancel);
        root.SetColumnSpan(buttons, 2);
        root.Controls.Add(buttons, 0, 4);

        AcceptButton = ok;
        CancelButton = cancel;
    }

    public int MinSparePercent => SelectedValue(_minSpare);
    public int MaxTemperatureC => SelectedValue(_maxTemperature);
    public int MaxWriteErrorsTotal => (int)_maxWriteErr.Value;
    public int LogRetentionDays => (int)_logRetention.Value;

    private static void ConfigureCombo(ComboBox combo, IEnumerable<int> values, string suffix, int selectedValue)
    {
        combo.DropDownStyle = ComboBoxStyle.DropDownList;
        combo.Dock = DockStyle.Left;
        combo.Width = 120;
        foreach (var value in values.Distinct().OrderBy(v => v))
            combo.Items.Add(new ThresholdOption($"{value}{suffix}", value));

        for (var i = 0; i < combo.Items.Count; i++)
        {
            if (combo.Items[i] is ThresholdOption option && option.Value == selectedValue)
            {
                combo.SelectedIndex = i;
                return;
            }
        }

        if (combo.Items.Count > 0)
            combo.SelectedIndex = 0;
    }

    private static int SelectedValue(ComboBox combo) =>
        combo.SelectedItem is ThresholdOption option ? option.Value : 0;
}

internal sealed class AppSettings
{
    public double ExpectedSizeGB { get; set; } = 128;
    public int ReadWriteTestMB { get; set; } = 256;
    public int MinReadWriteSpeedMBs { get; set; } = 230;
    public int MaxWearPercent { get; set; } = 10;
    public int MinSparePercent { get; set; } = 90;
    public int MaxTemperatureC { get; set; } = 70;
    public int MaxWriteErrorsTotal { get; set; } = 10;
    public int LogRetentionDays { get; set; } = 60;
    public Dictionary<string, int> HistoryColumnWidths { get; set; } = new(StringComparer.OrdinalIgnoreCase);

    private static string SettingsDirectory =>
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "NvmeUsbQuickCheck");

    private static string SettingsFile => Path.Combine(SettingsDirectory, "settings.json");

    public static AppSettings Load()
    {
        try
        {
            if (!File.Exists(SettingsFile))
                return new AppSettings();

            var json = File.ReadAllText(SettingsFile, Encoding.UTF8);
            var settings = JsonSerializer.Deserialize<AppSettings>(json, DiskScanner.JsonOptions) ?? new AppSettings();
            settings.HistoryColumnWidths ??= new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            settings.HistoryColumnWidths = new Dictionary<string, int>(settings.HistoryColumnWidths, StringComparer.OrdinalIgnoreCase);
            return settings;
        }
        catch
        {
            return new AppSettings();
        }
    }

    public void Save()
    {
        try
        {
            Directory.CreateDirectory(SettingsDirectory);
            var json = JsonSerializer.Serialize(this, DiskScanner.JsonOptions);
            File.WriteAllText(SettingsFile, json, Encoding.UTF8);
        }
        catch
        {
            // Einstellungen sind Komfortfunktion; Testlauf darf dadurch nicht scheitern.
        }
    }
}

internal sealed record CheckResult(
    DiskInfo Disk,
    bool Passed,
    bool SizeOk,
    bool HealthOk,
    bool SmartOk,
    bool ReadWriteOk,
    string SmartSummary,
    string ReadWriteSummary,
    string Details);

internal sealed record ReadWriteTestResult(
    bool Enabled,
    bool Passed,
    string Summary,
    string? Details);

internal sealed class MountResult
{
    public bool Success { get; set; }
    public string DriveLetters { get; set; } = "";
    public string TestPath { get; set; } = "";
    public string Action { get; set; } = "";
    public string Message { get; set; } = "";
}

internal sealed class DiskInfo
{
    public string FriendlyName { get; set; } = "";
    public string SerialNumber { get; set; } = "";
    public string UniqueId { get; set; } = "";
    public string BusType { get; set; } = "";
    public string MediaType { get; set; } = "";
    public string HealthStatus { get; set; } = "";
    public string OperationalStatus { get; set; } = "";
    public string DriveLetters { get; set; } = "";
    public int? DiskNumber { get; set; }
    public ulong SizeBytes { get; set; }
    public bool SmartAvailable { get; set; }
    public string SmartSource { get; set; } = "Windows";
    public string SmartDetails { get; set; } = "";
    public bool SmartCtlAvailable { get; set; }
    public bool CrystalDiskInfoAvailable { get; set; }
    public bool? SmartStatusPassed { get; set; }
    public long? CriticalWarning { get; set; }
    public long? ReadErrorsTotal { get; set; }
    public long? WriteErrorsTotal { get; set; }
    public long? Temperature { get; set; }
    public long? Wear { get; set; }
    public long? LifeRemaining { get; set; }
    public long? AvailableSpare { get; set; }
    public long? AvailableSpareThreshold { get; set; }
    public long? ReallocatedSectors { get; set; }
    public long? PendingSectors { get; set; }
    public long? UncorrectableErrors { get; set; }
    public long? CrcErrors { get; set; }
    public long? PowerOnHours { get; set; }
    public string WearLevelText { get; set; } = "";

    public string Key
    {
        get
        {
            var id = !string.IsNullOrWhiteSpace(UniqueId) ? UniqueId : SerialNumber;
            if (string.IsNullOrWhiteSpace(id))
                id = FriendlyName;

            var letters = string.IsNullOrWhiteSpace(DriveLetters) ? "-" : DriveLetters;
            var diskNumber = DiskNumber.HasValue ? DiskNumber.Value.ToString(CultureInfo.InvariantCulture) : "?";
            return $"{diskNumber}|{id}|{SizeBytes}|{BusType}|{letters}";
        }
    }

    public string PresenceKey
    {
        get
        {
            // Diese Kennung ist bewusst unabhängig von Laufwerksbuchstaben und GPT/Volume-UniqueId.
            // Beides ändert sich beim Formatieren und war die Ursache für erneute Tests desselben Laufwerks.
            var diskNumber = DiskNumber.HasValue ? DiskNumber.Value.ToString(CultureInfo.InvariantCulture) : "?";
            var stableId = IsUsableIdentity(SerialNumber) ? SerialNumber : FriendlyName;
            stableId = string.IsNullOrWhiteSpace(stableId) ? "unknown" : stableId.Trim();
            return $"{diskNumber}|{stableId}|{SizeBytes}|{BusType}";
        }
    }

    private static bool IsUsableIdentity(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return false;
        var s = value.Trim();
        return !s.Equals("n/a", StringComparison.OrdinalIgnoreCase)
               && !s.Equals("unknown", StringComparison.OrdinalIgnoreCase)
               && s.Length >= 4;
    }
}



internal static class CrystalDiskInfoProvider
{
    public static async Task EnrichAsync(DiskInfo disk)
    {
        if (!disk.DiskNumber.HasValue)
            return;

        var exe = FindDiskInfoExe();
        if (string.IsNullOrWhiteSpace(exe))
            return;

        var result = await RunCrystalDiskInfoAsync(exe, timeoutMs: 20000);
        if (string.IsNullOrWhiteSpace(result.Text))
            return;

        var block = FindBestDiskBlock(result.Text, disk);
        if (string.IsNullOrWhiteSpace(block))
            return;

        if (!ApplyCrystalDiskInfoText(disk, block))
            return;

        disk.CrystalDiskInfoAvailable = true;
        disk.SmartAvailable = true;
        disk.SmartSource = string.IsNullOrWhiteSpace(disk.SmartSource)
            ? "CrystalDiskInfo"
            : disk.SmartSource + "+CrystalDiskInfo";

        var details = $"CrystalDiskInfo ExitCode={result.ExitCode}";
        disk.SmartDetails = string.IsNullOrWhiteSpace(disk.SmartDetails) ? details : disk.SmartDetails + "; " + details;
    }

    private static bool ApplyCrystalDiskInfoText(DiskInfo disk, string text)
    {
        var applied = false;

        if (TryApplyCrystalSerialNumber(disk, text))
            applied = true;

        var cdiHealthPercentApplied = false;
        var health = MatchLineValue(text, "Health Status")
                  ?? MatchLineValue(text, "Gesamtzustand")
                  ?? MatchLineValue(text, "Health")
                  ?? MatchLineValue(text, "Zustand");

        if (!string.IsNullOrWhiteSpace(health))
        {
            applied = true;
            if (TryParsePercent(health, out var lifePercent))
            {
                SetLifeRemaining(disk, lifePercent, "CDI Health");
                cdiHealthPercentApplied = true;
            }

            var h = health.ToLowerInvariant();
            if (h.Contains("bad") || h.Contains("schlecht") || h.Contains("caution") || h.Contains("vorsicht") || h.Contains("warning") || h.Contains("warn"))
                disk.SmartStatusPassed = false;
            else if (h.Contains("good") || h.Contains("gut") || h.Contains("ok"))
                disk.SmartStatusPassed = true;
        }

        var powerOn = MatchLineValue(text, "Power On Hours")
                   ?? MatchLineValue(text, "Betriebsstunden")
                   ?? MatchLineValue(text, "Power-On Hours");
        if (TryParseFirstInteger(powerOn, out var poh))
        {
            disk.PowerOnHours = poh;
            applied = true;
        }

        var temp = MatchLineValue(text, "Temperature") ?? MatchLineValue(text, "Temperatur");
        if (TryParseFirstInteger(temp, out var t) && t > -50 && t < 150)
        {
            disk.Temperature = t;
            applied = true;
        }

        var wearLevelCount = MatchLineValue(text, "Wear Level Count")
                          ?? MatchLineValue(text, "Wear Leveling Count")
                          ?? MatchLineValue(text, "Verschleißregulierung");
        if (!cdiHealthPercentApplied && TryParseFirstInteger(wearLevelCount, out var wlcRaw))
        {
            // CrystalDiskInfo zeigt WLC/Wear-Leveling bei vielen SSDs als Health/Life Remaining.
            // Falls aber der CDI-Gesamtzustand bereits einen Prozentwert liefert, ist dieser maßgeblich.
            if (wlcRaw >= 0 && wlcRaw <= 100)
                SetLifeRemaining(disk, wlcRaw, "CDI WLC");
            else if (string.IsNullOrWhiteSpace(disk.WearLevelText))
                disk.WearLevelText = $"CDI WLC raw {wlcRaw}";
            applied = true;
        }

        foreach (var line in ReadLines(text))
        {
            if (!TryParseCrystalSmartAttributeLine(line, out var id, out var current, out var raw, out var name))
                continue;

            var key = CanonicalAttributeName(name);
            if (string.IsNullOrWhiteSpace(key))
                continue;

            if (key.Contains("criticalwarning"))
                disk.CriticalWarning = MaxNullable(disk.CriticalWarning, raw);
            else if (key.Contains("availablesparethreshold"))
                disk.AvailableSpareThreshold = raw;
            else if (key.Contains("availablespare"))
                disk.AvailableSpare = raw;
            else if (key.Contains("percentageused") || key.Contains("percentused"))
            {
                if (raw.HasValue)
                    SetWearUsed(disk, raw.Value, "CDI Wear");
                applied = true;
            }
            else if (key.Contains("mediaanddataintegrityerrors") || key.Contains("mediaerrors"))
                disk.ReadErrorsTotal = MaxNullable(disk.ReadErrorsTotal, raw);
            else if (key.Contains("errorinformationlogentries") || key.Contains("errorlogentries"))
                disk.WriteErrorsTotal = MaxNullable(disk.WriteErrorsTotal, raw);
            else if (id == 5 || key.Contains("reallocatedsector"))
                disk.ReallocatedSectors = MaxNullable(disk.ReallocatedSectors, raw);
            else if (id == 197 || key.Contains("pendingsector"))
                disk.PendingSectors = MaxNullable(disk.PendingSectors, raw);
            else if (id == 198 || key.Contains("uncorrectable"))
                disk.UncorrectableErrors = MaxNullable(disk.UncorrectableErrors, raw);
            else if (id == 199 || key.Contains("crcerror") || key.Contains("udmacrc"))
                disk.CrcErrors = MaxNullable(disk.CrcErrors, raw);

            if (!cdiHealthPercentApplied && (key.Contains("wearlevel") || key.Contains("wearleveling")))
            {
                // WLC/Wear-Leveling ist nicht bei allen Herstellern gleich. Wenn CDI bereits
                // einen Health-Prozentwert liefert, hat dieser Vorrang vor einzelnen Attributen.
                if (current.HasValue && current.Value >= 0 && current.Value <= 100)
                    SetLifeRemaining(disk, current.Value, "CDI WLC");
                else if (raw.HasValue && raw.Value >= 0 && raw.Value <= 100)
                    SetLifeRemaining(disk, raw.Value, "CDI WLC raw");
                else if (raw.HasValue && string.IsNullOrWhiteSpace(disk.WearLevelText))
                    disk.WearLevelText = $"CDI WLC raw {raw.Value}";
                applied = true;
            }
            else if (!cdiHealthPercentApplied && (key.Contains("ssdlifeleft") || key.Contains("medialife") || key.Contains("liferemaining") || key.Contains("remaininglife") || key.Contains("mediawearoutindicator")))
            {
                var life = current.HasValue && current.Value >= 0 && current.Value <= 100 ? current.Value : raw;
                if (life.HasValue && life.Value >= 0 && life.Value <= 100)
                {
                    SetLifeRemaining(disk, life.Value, "CDI Life");
                    applied = true;
                }
            }
            else if (!cdiHealthPercentApplied && (key.Contains("percentageused") || key.Contains("percentused") || key.Contains("lifetimeused")))
            {
                var used = raw.HasValue && raw.Value >= 0 && raw.Value <= 255 ? raw : current;
                if (used.HasValue && used.Value >= 0)
                {
                    SetWearUsed(disk, used.Value, "CDI Wear");
                    applied = true;
                }
            }
        }

        return applied;
    }


    private static bool TryApplyCrystalSerialNumber(DiskInfo disk, string text)
    {
        var serial = MatchLineValue(text, "Serial Number")
                  ?? MatchLineValue(text, "Seriennummer")
                  ?? MatchLineValue(text, "Serial No")
                  ?? MatchLineValue(text, "S/N");

        serial = CleanSerialFromCrystal(serial);
        if (string.IsNullOrWhiteSpace(serial))
            return false;

        // CrystalDiskInfo liest die Seriennummer meist direkt aus dem SSD-/NVMe-SMART-Block.
        // Daher darf dieser Wert eine schwache Windows-/USB-Bridge-Seriennummer wie "n/a" ersetzen.
        disk.SerialNumber = serial;
        return true;
    }

    private static string CleanSerialFromCrystal(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return string.Empty;

        var s = value.Trim().Trim('"', '\'');
        var sb = new StringBuilder(s.Length);
        foreach (var ch in s)
        {
            if (!char.IsControl(ch))
                sb.Append(ch);
        }

        s = sb.ToString().Trim();
        if (string.IsNullOrWhiteSpace(s))
            return string.Empty;

        if (s.Equals("n/a", StringComparison.OrdinalIgnoreCase)
            || s.Equals("unknown", StringComparison.OrdinalIgnoreCase)
            || s.Equals("none", StringComparison.OrdinalIgnoreCase)
            || s.Equals("null", StringComparison.OrdinalIgnoreCase))
            return string.Empty;

        // Offensichtliche USB-Bridge-Platzhalter weiterhin verwerfen.
        var zeroCount = s.Count(ch => ch == '0');
        if (System.Text.RegularExpressions.Regex.IsMatch(s, @"^[0-9A-Fa-f]{12,}$")
            && zeroCount >= Math.Ceiling(s.Length * 0.55))
            return string.Empty;

        return s;
    }

    private static long? MaxNullable(long? existing, long? value)
    {
        if (!value.HasValue)
            return existing;
        return Math.Max(existing.GetValueOrDefault(), value.Value);
    }

    private static void SetLifeRemaining(DiskInfo disk, long life, string source)
    {
        life = Math.Max(0, Math.Min(100, life));
        var wear = 100 - life;
        disk.LifeRemaining = life;
        disk.Wear = wear;
        disk.WearLevelText = $"{source} Health {life}% / Wear {wear}%";
    }

    private static void SetWearUsed(DiskInfo disk, long wear, string source)
    {
        wear = Math.Max(0, wear);
        disk.Wear = wear;
        if (wear <= 100)
        {
            var life = 100 - wear;
            disk.LifeRemaining = life;
            disk.WearLevelText = $"{source} Wear {wear}% / Health {life}%";
        }
        else
        {
            disk.WearLevelText = $"{source} Wear >100%";
        }
    }

    private static string? FindBestDiskBlock(string text, DiskInfo disk)
    {
        var blocks = SplitIntoDiskBlocks(text);
        if (blocks.Count == 0)
            blocks.Add(text);

        var bestScore = int.MinValue;
        string? best = null;
        foreach (var block in blocks)
        {
            var score = ScoreBlock(block, disk);
            if (score > bestScore)
            {
                bestScore = score;
                best = block;
            }
        }

        return bestScore >= 3 ? best : null;
    }

    private static List<string> SplitIntoDiskBlocks(string text)
    {
        var normalized = text.Replace("\r\n", "\n").Replace('\r', '\n');
        var lines = normalized.Split('\n');
        var blocks = new List<string>();
        var current = new StringBuilder();
        var inDisk = false;

        foreach (var line in lines)
        {
            var trimmed = line.Trim();
            var isSeparator = System.Text.RegularExpressions.Regex.IsMatch(trimmed, @"^-{5,}$");
            var isDiskHeader = System.Text.RegularExpressions.Regex.IsMatch(trimmed, @"^\(\d+\)\s+.+");

            if ((isSeparator || isDiskHeader) && current.Length > 0 && ContainsDiskData(current.ToString()))
            {
                blocks.Add(current.ToString());
                current.Clear();
                inDisk = false;
            }

            if (trimmed.Contains("Disk Size", StringComparison.OrdinalIgnoreCase)
                || trimmed.Contains("Health Status", StringComparison.OrdinalIgnoreCase)
                || trimmed.Contains("Gesamtzustand", StringComparison.OrdinalIgnoreCase)
                || trimmed.Contains("Serial Number", StringComparison.OrdinalIgnoreCase)
                || trimmed.Contains("-- S.M.A.R.T.", StringComparison.OrdinalIgnoreCase)
                || isDiskHeader)
            {
                inDisk = true;
            }

            if (inDisk || current.Length > 0)
                current.AppendLine(line);
        }

        if (current.Length > 0 && ContainsDiskData(current.ToString()))
            blocks.Add(current.ToString());

        return blocks;
    }

    private static bool ContainsDiskData(string block)
    {
        return block.Contains("Disk Size", StringComparison.OrdinalIgnoreCase)
            || block.Contains("Health Status", StringComparison.OrdinalIgnoreCase)
            || block.Contains("Gesamtzustand", StringComparison.OrdinalIgnoreCase)
            || block.Contains("S.M.A.R.T", StringComparison.OrdinalIgnoreCase);
    }

    private static int ScoreBlock(string block, DiskInfo disk)
    {
        var score = 0;
        var text = NormalizeForCompare(block);

        if (disk.DiskNumber.HasValue && System.Text.RegularExpressions.Regex.IsMatch(block, @"\bpd\s*" + disk.DiskNumber.Value + @"\b", System.Text.RegularExpressions.RegexOptions.IgnoreCase))
            score += 20;

        var serial = NormalizeForCompare(disk.SerialNumber);
        if (!string.IsNullOrWhiteSpace(serial) && serial != "na" && text.Contains(serial))
            score += 15;

        var unique = NormalizeForCompare(disk.UniqueId);
        if (!string.IsNullOrWhiteSpace(unique) && text.Contains(unique))
            score += 8;

        var model = NormalizeForCompare(disk.FriendlyName);
        if (!string.IsNullOrWhiteSpace(model))
        {
            if (text.Contains(model))
                score += 8;
            else
            {
                foreach (var token in model.Split(' ', StringSplitOptions.RemoveEmptyEntries).Where(t => t.Length >= 5).Take(3))
                {
                    if (text.Contains(token))
                        score += 2;
                }
            }
        }

        if (TryParseDiskSizeBytes(block, out var bytes))
        {
            var diff = Math.Abs((double)bytes - disk.SizeBytes) / Math.Max(1d, disk.SizeBytes);
            if (diff < 0.02)
                score += 6;
            else if (diff < 0.08)
                score += 3;
        }

        if (!string.IsNullOrWhiteSpace(disk.DriveLetters))
        {
            foreach (var letter in disk.DriveLetters.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
            {
                if (System.Text.RegularExpressions.Regex.IsMatch(block, @"\b" + System.Text.RegularExpressions.Regex.Escape(letter) + @":", System.Text.RegularExpressions.RegexOptions.IgnoreCase))
                    score += 3;
            }
        }

        return score;
    }

    private static bool TryParseDiskSizeBytes(string block, out ulong bytes)
    {
        bytes = 0;
        var value = MatchLineValue(block, "Disk Size") ?? MatchLineValue(block, "Kapazität") ?? MatchLineValue(block, "Total Size");
        if (string.IsNullOrWhiteSpace(value))
        {
            var m = System.Text.RegularExpressions.Regex.Match(block, @"(?<num>\d+(?:[\.,]\d+)?)\s*(?<unit>TB|GB|GiB|TiB)\b", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (!m.Success)
                return false;
            value = m.Value;
        }

        var match = System.Text.RegularExpressions.Regex.Match(value, @"(?<num>\d+(?:[\.,]\d+)?)\s*(?<unit>TB|GB|GiB|TiB)\b", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
        if (!match.Success)
            return false;

        var numText = match.Groups["num"].Value.Replace(',', '.');
        if (!double.TryParse(numText, NumberStyles.Float, CultureInfo.InvariantCulture, out var num))
            return false;

        var unit = match.Groups["unit"].Value.ToUpperInvariant();
        var factor = unit switch
        {
            "TB" => 1000d * 1000d * 1000d * 1000d,
            "GB" => 1000d * 1000d * 1000d,
            "TIB" => 1024d * 1024d * 1024d * 1024d,
            "GIB" => 1024d * 1024d * 1024d,
            _ => 1d
        };
        bytes = (ulong)Math.Max(0d, num * factor);
        return true;
    }

    private static bool TryParseCrystalSmartAttributeLine(string line, out long id, out long? current, out long? raw, out string name)
    {
        id = -1;
        current = null;
        raw = null;
        name = string.Empty;

        var trimmed = line.Trim();
        if (string.IsNullOrWhiteSpace(trimmed))
            return false;

        // CrystalDiskInfo ATA/SATA-Zeile:
        // ID Cur Wor Thr RawValues(6) Attribute Name
        // 05 100 100 _10 000000000000 Reallocated Sectors Count
        var ata = System.Text.RegularExpressions.Regex.Match(trimmed,
            @"^(?<id>[0-9A-Fa-f]{1,3})\s+(?<cur>[_\d]{1,3})\s+(?<wor>[_\d]{1,3})\s+(?<thr>[_\d]{1,3})\s+(?<raw>[0-9A-Fa-f`_\-]{2,})\s+(?<name>.+)$");
        if (ata.Success)
        {
            id = ParseSmartId(ata.Groups["id"].Value);
            current = ParseNormalizedSmartNumber(ata.Groups["cur"].Value);
            raw = ParseCrystalRawValue(ata.Groups["raw"].Value);
            name = ata.Groups["name"].Value.Trim();
            return !string.IsNullOrWhiteSpace(name);
        }

        // CrystalDiskInfo NVMe-Zeile:
        // ID RawValues(6) Attribute Name
        // 05 000000000003 Percentage Used
        var nvme = System.Text.RegularExpressions.Regex.Match(trimmed,
            @"^(?<id>[0-9A-Fa-f]{1,3})\s+(?<raw>[0-9A-Fa-f`_\-]{2,})\s+(?<name>.+)$");
        if (nvme.Success)
        {
            id = ParseSmartId(nvme.Groups["id"].Value);
            raw = ParseCrystalRawValue(nvme.Groups["raw"].Value);
            name = nvme.Groups["name"].Value.Trim();
            return !string.IsNullOrWhiteSpace(name);
        }

        return false;
    }

    private static long ParseSmartId(string idText)
    {
        if (long.TryParse(idText, NumberStyles.Integer, CultureInfo.InvariantCulture, out var dec))
            return dec;
        if (long.TryParse(idText, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out var hex))
            return hex;
        return -1;
    }

    private static long? ParseNormalizedSmartNumber(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return null;
        var cleaned = new string(value.Where(char.IsDigit).ToArray());
        if (long.TryParse(cleaned, NumberStyles.Integer, CultureInfo.InvariantCulture, out var n))
            return n;
        return null;
    }

    private static long? ParseCrystalRawValue(string raw)
    {
        if (string.IsNullOrWhiteSpace(raw))
            return null;
        var cleaned = raw.Replace("_", "").Replace("`", "").Replace("-", "").Trim();
        if (string.IsNullOrWhiteSpace(cleaned))
            return null;

        // CrystalDiskInfo RawValues(6) ist hexadezimal. Für Werte wie 000000000064
        // muss daher 100 herauskommen, nicht 64.
        if (cleaned.All(Uri.IsHexDigit) && cleaned.Length >= 2 && cleaned.Length <= 16
            && long.TryParse(cleaned, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out var hex))
            return hex;

        if (long.TryParse(cleaned, NumberStyles.Integer, CultureInfo.InvariantCulture, out var dec))
            return dec;
        return null;
    }

    private static long? ParseRawValue(string raw)
    {
        if (string.IsNullOrWhiteSpace(raw))
            return null;
        var cleaned = raw.Replace("_", "").Replace("`", "").Replace("-", "").Trim();
        if (long.TryParse(cleaned, NumberStyles.Integer, CultureInfo.InvariantCulture, out var dec))
            return dec;
        if (cleaned.Length <= 16 && long.TryParse(cleaned, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out var hex))
            return hex;
        return null;
    }

    private static string? MatchLineValue(string text, string key)
    {
        foreach (var line in ReadLines(text))
        {
            var idx = line.IndexOf(':');
            if (idx < 0)
                continue;
            var left = line[..idx].Trim();
            if (left.Equals(key, StringComparison.OrdinalIgnoreCase))
                return line[(idx + 1)..].Trim();
        }
        return null;
    }

    private static IEnumerable<string> ReadLines(string text)
    {
        using var sr = new StringReader(text ?? string.Empty);
        string? line;
        while ((line = sr.ReadLine()) != null)
            yield return line;
    }

    private static bool TryParsePercent(string? text, out long percent)
    {
        percent = 0;
        if (string.IsNullOrWhiteSpace(text))
            return false;
        var match = System.Text.RegularExpressions.Regex.Match(text, @"(?<p>\d{1,3})\s*%");
        return match.Success && long.TryParse(match.Groups["p"].Value, NumberStyles.Integer, CultureInfo.InvariantCulture, out percent);
    }

    private static bool TryParseFirstInteger(string? text, out long value)
    {
        value = 0;
        if (string.IsNullOrWhiteSpace(text))
            return false;
        var match = System.Text.RegularExpressions.Regex.Match(text, @"-?\d+");
        return match.Success && long.TryParse(match.Value, NumberStyles.Integer, CultureInfo.InvariantCulture, out value);
    }

    private static string CanonicalAttributeName(string? name)
    {
        if (string.IsNullOrWhiteSpace(name))
            return string.Empty;
        var sb = new StringBuilder(name.Length);
        foreach (var ch in name.ToLowerInvariant())
        {
            if (char.IsLetterOrDigit(ch))
                sb.Append(ch);
        }
        return sb.ToString();
    }

    private static string NormalizeForCompare(string? text)
    {
        if (string.IsNullOrWhiteSpace(text))
            return string.Empty;
        var sb = new StringBuilder(text.Length);
        foreach (var ch in text.ToLowerInvariant())
        {
            if (char.IsLetterOrDigit(ch))
                sb.Append(ch);
        }
        return sb.ToString();
    }

    private static async Task<(int ExitCode, string Text)> RunCrystalDiskInfoAsync(string exe, int timeoutMs)
    {
        var exeDir = Path.GetDirectoryName(exe) ?? AppContext.BaseDirectory;
        var candidateDirs = new[]
        {
            exeDir,
            AppContext.BaseDirectory,
            Path.Combine(AppContext.BaseDirectory, "CrystalDiskInfo"),
            Path.GetTempPath()
        }
        .Where(d => !string.IsNullOrWhiteSpace(d))
        .Distinct(StringComparer.OrdinalIgnoreCase)
        .ToArray();

        var beforeUtc = DateTime.UtcNow.AddSeconds(-2);
        foreach (var path in candidateDirs.Select(d => Path.Combine(d, "DiskInfo.txt")))
        {
            try { if (File.Exists(path)) File.Delete(path); } catch { }
        }

        try
        {
            var psi = new ProcessStartInfo
            {
                FileName = exe,
                Arguments = "/CopyExit",
                WorkingDirectory = exeDir,
                UseShellExecute = false,
                RedirectStandardOutput = false,
                RedirectStandardError = false,
                CreateNoWindow = true,
            };

            using var p = new Process { StartInfo = psi };
            p.Start();

            using var timeout = new CancellationTokenSource(timeoutMs);
            try
            {
                await p.WaitForExitAsync(timeout.Token);
            }
            catch (OperationCanceledException)
            {
                try
                {
                    if (!p.HasExited)
                        p.Kill(entireProcessTree: true);
                }
                catch { }
                return (-999, string.Empty);
            }

            // CrystalDiskInfo dokumentiert /CopyExit als Ausgabe nach DiskInfo.txt.
            // Je nach Portable-/Installationsvariante landet die Datei im EXE-Ordner,
            // WorkingDirectory oder in einem Unterordner. Deshalb robust suchen.
            for (var i = 0; i < 20; i++)
            {
                foreach (var path in EnumerateRecentDiskInfoReports(candidateDirs, beforeUtc))
                {
                    var text = await ReadAllTextSharedAsync(path);
                    if (LooksLikeCrystalDiskInfoReport(text))
                        return (p.ExitCode, text);
                }

                await Task.Delay(150);
            }

            // Sicherheitsnetz: Einige Builds/Setups liefern den Copy-Text auch über die Zwischenablage.
            try
            {
                if (Clipboard.ContainsText())
                {
                    var clip = Clipboard.GetText(TextDataFormat.Text);
                    if (LooksLikeCrystalDiskInfoReport(clip))
                        return (p.ExitCode, clip);
                }
            }
            catch { }

            return (p.ExitCode, string.Empty);
        }
        catch
        {
            return (-998, string.Empty);
        }
    }

    private static IEnumerable<string> EnumerateRecentDiskInfoReports(IEnumerable<string> dirs, DateTime minUtc)
    {
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var dir in dirs)
        {
            if (string.IsNullOrWhiteSpace(dir) || !Directory.Exists(dir))
                continue;

            IEnumerable<string> files;
            try
            {
                files = Directory.EnumerateFiles(dir, "DiskInfo*.txt", SearchOption.TopDirectoryOnly);
            }
            catch
            {
                continue;
            }

            foreach (var file in files)
            {
                if (!seen.Add(file))
                    continue;

                DateTime lastWriteUtc;
                try { lastWriteUtc = File.GetLastWriteTimeUtc(file); } catch { continue; }
                if (lastWriteUtc >= minUtc)
                    yield return file;
            }
        }
    }

    private static bool LooksLikeCrystalDiskInfoReport(string? text)
    {
        if (string.IsNullOrWhiteSpace(text))
            return false;
        return text.Contains("CrystalDiskInfo", StringComparison.OrdinalIgnoreCase)
               || text.Contains("Health Status", StringComparison.OrdinalIgnoreCase)
               || text.Contains("Gesamtzustand", StringComparison.OrdinalIgnoreCase)
               || text.Contains("S.M.A.R.T", StringComparison.OrdinalIgnoreCase);
    }

    private static async Task<string> ReadAllTextSharedAsync(string path)
    {
        try
        {
            await using var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
            using var reader = new StreamReader(fs, Encoding.Default, detectEncodingFromByteOrderMarks: true);
            return await reader.ReadToEndAsync();
        }
        catch
        {
            try { return await File.ReadAllTextAsync(path, Encoding.Default); } catch { return string.Empty; }
        }
    }

    private static string FindDiskInfoExe()
    {
        var baseDir = AppContext.BaseDirectory;
        var names = Environment.Is64BitOperatingSystem
            ? new[] { "DiskInfo64.exe", "DiskInfo32.exe", "DiskInfoA64.exe" }
            : new[] { "DiskInfo32.exe", "DiskInfo64.exe" };

        var dirs = new List<string>
        {
            baseDir,
            Path.Combine(baseDir, "CrystalDiskInfo"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "CrystalDiskInfo"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "CrystalDiskInfo"),
        };

        foreach (var dir in dirs.Where(d => !string.IsNullOrWhiteSpace(d)).Distinct(StringComparer.OrdinalIgnoreCase))
        {
            foreach (var name in names)
            {
                try
                {
                    var path = Path.Combine(dir, name);
                    if (File.Exists(path))
                        return path;
                }
                catch { }
            }
        }

        return string.Empty;
    }
}


internal static class SmartCtl
{
    private static readonly string[] DeviceTypeAttempts =
    {
        "",
        "-d nvme",
        "-d sntasmedia",
        "-d sntasmedia/sat",
        "-d sntjmicron",
        "-d sntjmicron/sat",
        "-d sntrealtek",
        "-d sntrealtek/sat",
        "-d sat",
        "-d sat,12",
        "-d sat,16",
        "-d scsi"
    };

    public static async Task EnrichAsync(DiskInfo disk)
    {
        if (!disk.DiskNumber.HasValue)
            return;

        var exe = FindSmartCtlExe();
        if (string.IsNullOrWhiteSpace(exe))
        {
            if (string.IsNullOrWhiteSpace(disk.SmartSource))
                disk.SmartSource = "Windows";
            return;
        }

        foreach (var deviceType in DeviceTypeAttempts)
        {
            var args = BuildArguments(deviceType, disk.DiskNumber.Value);
            var run = await RunSmartCtlAsync(exe, args, 2500);
            if (string.IsNullOrWhiteSpace(run.Output))
                continue;

            if (!TryApplySmartCtlJson(disk, run.Output, deviceType, run.ExitCode))
                continue;

            return;
        }
    }

    private static string BuildArguments(string deviceType, int diskNumber)
    {
        var device = $@"\\.\PhysicalDrive{diskNumber}";
        if (string.IsNullOrWhiteSpace(deviceType))
            return $"-j -a {Quote(device)}";
        return $"-j -a {deviceType} {Quote(device)}";
    }

    private static bool TryApplySmartCtlJson(DiskInfo disk, string json, string deviceType, int exitCode)
    {
        try
        {
            using var doc = JsonDocument.Parse(json);
            var root = doc.RootElement;

            var hasUsefulData = false;
            bool? smartPassed = null;
            long? criticalWarning = null;
            long? mediaErrors = null;
            long? errorLogEntries = null;
            long? temp = null;

            if (TryGetProperty(root, "smart_status", out var smartStatus) && TryGetBool(smartStatus, "passed", out var passed))
            {
                smartPassed = passed;
                hasUsefulData = true;
            }

            if (TryGetProperty(root, "temperature", out var temperature))
            {
                if (TryGetInt64(temperature, "current", out var t)) { temp = t; hasUsefulData = true; }
            }

            if (TryGetProperty(root, "power_on_time", out var powerOnTime) && TryGetInt64(powerOnTime, "hours", out var poh))
            {
                disk.PowerOnHours = poh;
                hasUsefulData = true;
            }

            if (TryGetProperty(root, "nvme_smart_health_information_log", out var nvme))
            {
                if (TryGetInt64(nvme, "critical_warning", out var cw)) { criticalWarning = cw; hasUsefulData = true; }
                if (TryGetInt64(nvme, "media_errors", out var me)) { mediaErrors = me; hasUsefulData = true; }
                if (TryGetInt64(nvme, "num_err_log_entries", out var el)) { errorLogEntries = el; hasUsefulData = true; }
                if (!temp.HasValue && TryGetInt64(nvme, "temperature", out var nt)) { temp = nt; hasUsefulData = true; }
                if (TryGetInt64(nvme, "percentage_used", out var pu)) { ApplyWearUsed(disk, pu, "NVMe"); hasUsefulData = true; }
                if (TryGetInt64(nvme, "available_spare", out var spare)) { disk.AvailableSpare = spare; hasUsefulData = true; }
                if (TryGetInt64(nvme, "available_spare_threshold", out var threshold)) { disk.AvailableSpareThreshold = threshold; hasUsefulData = true; }
            }

            if (TryGetProperty(root, "ata_smart_attributes", out var ata) && TryGetProperty(ata, "table", out var table) && table.ValueKind == JsonValueKind.Array)
            {
                foreach (var attr in table.EnumerateArray())
                {
                    if (!TryGetInt64(attr, "id", out var id))
                        id = -1;

                    var name = TryGetString(attr, "name", out var n) ? n : string.Empty;
                    var key = CanonicalAttributeName(name);
                    var hasValue = TryGetInt64(attr, "value", out var normalizedValue);
                    var hasWorst = TryGetInt64(attr, "worst", out var worstValue);
                    var raw = GetRawAttributeValue(attr);

                    if (hasValue || raw.HasValue)
                        hasUsefulData = true;

                    if (!temp.HasValue && (id == 190 || id == 194 || key.Contains("temperature")) && raw.HasValue)
                    {
                        // Viele ATA-SSDs speichern die aktuelle Temperatur als erste Zahl im RAW-Feld.
                        temp = raw.Value;
                    }

                    if (id == 5 || key.Contains("reallocatedsector"))
                        disk.ReallocatedSectors = ChooseRawOrValue(raw, hasValue ? normalizedValue : null);
                    else if (id == 197 || key.Contains("currentpendingsector") || key.Contains("pendingsector"))
                        disk.PendingSectors = ChooseRawOrValue(raw, hasValue ? normalizedValue : null);
                    else if (id == 198 || key.Contains("offlineuncorrectable") || key.Contains("uncorrectableerror"))
                        disk.UncorrectableErrors = ChooseRawOrValue(raw, hasValue ? normalizedValue : null);
                    else if (id == 199 || key.Contains("udmacrc") || key.Contains("crcerror"))
                        disk.CrcErrors = ChooseRawOrValue(raw, hasValue ? normalizedValue : null);
                    else if (id == 187 || key.Contains("reporteduncorrect") || key.Contains("reporteduncorrectable"))
                        disk.UncorrectableErrors = Math.Max(disk.UncorrectableErrors.GetValueOrDefault(), ChooseRawOrValue(raw, hasValue ? normalizedValue : null).GetValueOrDefault());

                    if (id == 9 || key.Contains("poweronhours"))
                    {
                        var pohValue = ChooseRawOrValue(raw, hasValue ? normalizedValue : null);
                        if (pohValue.HasValue)
                            disk.PowerOnHours = pohValue.Value;
                    }

                    ApplyAtaWearAttribute(disk, id, name, key, hasValue ? normalizedValue : null, hasWorst ? worstValue : null, raw);
                }
            }

            if (TryGetProperty(root, "scsi_grown_defect_list", out var grownDefects) && TryGetInt64(grownDefects, out var grown))
            {
                disk.ReallocatedSectors = grown;
                hasUsefulData = true;
            }

            if (!hasUsefulData)
                return false;

            disk.SmartAvailable = true;
            disk.SmartCtlAvailable = true;
            disk.SmartSource = string.IsNullOrWhiteSpace(deviceType) ? "smartctl" : $"smartctl {deviceType}";
            disk.SmartDetails = $"smartctl ExitCode={exitCode}";
            disk.SmartStatusPassed = smartPassed ?? disk.SmartStatusPassed;
            disk.CriticalWarning = criticalWarning ?? disk.CriticalWarning;
            disk.ReadErrorsTotal = mediaErrors ?? disk.ReadErrorsTotal;
            disk.WriteErrorsTotal = errorLogEntries ?? disk.WriteErrorsTotal;
            disk.Temperature = temp ?? disk.Temperature;
            return true;
        }
        catch
        {
            return false;
        }
    }

    private static void ApplyAtaWearAttribute(DiskInfo disk, long id, string name, string key, long? normalizedValue, long? worstValue, long? raw)
    {
        var label = string.IsNullOrWhiteSpace(name) ? $"Attr{id}" : name.Replace('_', ' ');

        // NVMe hat Percentage Used. ATA/SATA-SSDs sind herstellerspezifisch: viele Wear-/Life-Attribute
        // verwenden einen normalisierten Wert, der bei 100 neu beginnt und Richtung 0 fällt.
        if (key.Contains("wearleveling") || key.Contains("wearlevelingcount"))
        {
            if (normalizedValue.HasValue && IsPercentLike(normalizedValue.Value))
            {
                var life = ClampPercent(normalizedValue.Value);
                ApplyLifeRemaining(disk, life, "WLC", raw);
            }
            else if (raw.HasValue && IsPercentLike(raw.Value))
            {
                // Auch smartctl-WLC-Rohwerte im Prozentbereich werden als Life/Health Remaining behandelt.
                ApplyLifeRemaining(disk, ClampPercent(raw.Value), "WLC raw", raw);
            }
            return;
        }

        if (key.Contains("mediawearoutindicator") || key.Contains("ssdlifeleft") || key.Contains("lifetimeremain") || key.Contains("remaininglifetime") || key.Contains("percentlifetimeleft") || key.Contains("liferemaining"))
        {
            var lifeSource = normalizedValue.HasValue && IsPercentLike(normalizedValue.Value)
                ? normalizedValue
                : raw.HasValue && IsPercentLike(raw.Value) ? raw : null;

            if (lifeSource.HasValue)
            {
                ApplyLifeRemaining(disk, ClampPercent(lifeSource.Value), CompactLabel(label), raw);
            }
            return;
        }

        if (key.Contains("percentageused") || key.Contains("percentagelifetimeused") || key.Contains("lifetimeused") || key.Contains("wearout") || key.Contains("wearused"))
        {
            var wearSource = raw.HasValue && raw.Value >= 0 && raw.Value <= 255
                ? raw
                : normalizedValue.HasValue && normalizedValue.Value >= 0 && normalizedValue.Value <= 255 ? normalizedValue : null;

            if (wearSource.HasValue)
            {
                ApplyWearUsed(disk, wearSource.Value, CompactLabel(label));
            }
        }
    }

    private static void ApplyWearUsed(DiskInfo disk, long wearUsed, string source)
    {
        var wear = Math.Max(0, wearUsed);
        disk.Wear = wear;
        if (wear <= 100)
            disk.LifeRemaining = 100 - wear;
        if (string.IsNullOrWhiteSpace(disk.WearLevelText))
        {
            if (wear <= 100)
                disk.WearLevelText = $"{source} Wear {wear}% / Health {100 - wear}%";
            else
                disk.WearLevelText = $"{source} Wear >100%";
        }
    }

    private static void ApplyLifeRemaining(DiskInfo disk, long lifeRemaining, string source, long? raw)
    {
        var life = ClampPercent(lifeRemaining);
        var wear = 100 - life;
        disk.LifeRemaining = life;
        disk.Wear = wear;
        if (!string.IsNullOrWhiteSpace(disk.WearLevelText))
            return;

        if (raw.HasValue && raw.Value > 100)
            disk.WearLevelText = $"{source} Health {life}% / Wear {wear}% raw {raw.Value}";
        else
            disk.WearLevelText = $"{source} Health {life}% / Wear {wear}%";
    }

    private static long ClampPercent(long value) => Math.Max(0, Math.Min(100, value));
    private static bool IsPercentLike(long value) => value >= 0 && value <= 100;

    private static string CompactLabel(string label)
    {
        label = (label ?? string.Empty).Trim();
        if (label.Length <= 12)
            return label;
        if (label.Contains("Wear", StringComparison.OrdinalIgnoreCase))
            return "Wear";
        if (label.Contains("Life", StringComparison.OrdinalIgnoreCase))
            return "Life";
        return label[..12];
    }

    private static long? ChooseRawOrValue(long? raw, long? value)
    {
        if (raw.HasValue)
            return raw.Value;
        if (value.HasValue)
            return value.Value;
        return null;
    }

    private static long? GetRawAttributeValue(JsonElement attr)
    {
        if (!TryGetProperty(attr, "raw", out var raw))
            return null;

        if (TryGetInt64(raw, "value", out var value))
            return value;

        if (TryGetString(raw, "string", out var rawString) && TryParseFirstInteger(rawString, out value))
            return value;

        if (TryGetInt64(raw, out value))
            return value;

        return null;
    }

    private static bool TryParseFirstInteger(string? text, out long value)
    {
        value = 0;
        if (string.IsNullOrWhiteSpace(text))
            return false;

        var match = System.Text.RegularExpressions.Regex.Match(text, @"-?\d+");
        return match.Success && long.TryParse(match.Value, NumberStyles.Integer, CultureInfo.InvariantCulture, out value);
    }

    private static string CanonicalAttributeName(string? name)
    {
        if (string.IsNullOrWhiteSpace(name))
            return string.Empty;

        var sb = new StringBuilder(name.Length);
        foreach (var ch in name.ToLowerInvariant())
        {
            if (char.IsLetterOrDigit(ch))
                sb.Append(ch);
        }
        return sb.ToString();
    }

    private static bool TryGetProperty(JsonElement element, string name, out JsonElement value)
    {
        if (element.ValueKind == JsonValueKind.Object && element.TryGetProperty(name, out value))
            return true;
        value = default;
        return false;
    }

    private static bool TryGetString(JsonElement element, string name, out string value)
    {
        if (TryGetProperty(element, name, out var prop) && prop.ValueKind == JsonValueKind.String)
        {
            value = prop.GetString() ?? string.Empty;
            return true;
        }

        value = string.Empty;
        return false;
    }

    private static bool TryGetBool(JsonElement element, string name, out bool value)
    {
        if (TryGetProperty(element, name, out var prop))
        {
            if (prop.ValueKind == JsonValueKind.True) { value = true; return true; }
            if (prop.ValueKind == JsonValueKind.False) { value = false; return true; }
        }
        value = false;
        return false;
    }

    private static bool TryGetInt64(JsonElement element, string name, out long value)
    {
        if (TryGetProperty(element, name, out var prop))
            return TryGetInt64(prop, out value);
        value = 0;
        return false;
    }

    private static bool TryGetInt64(JsonElement element, out long value)
    {
        if (element.ValueKind == JsonValueKind.Number && element.TryGetInt64(out value))
            return true;

        if (element.ValueKind == JsonValueKind.String && long.TryParse(element.GetString(), NumberStyles.Integer, CultureInfo.InvariantCulture, out value))
            return true;

        if (element.ValueKind == JsonValueKind.Object)
        {
            if (element.TryGetProperty("value", out var valueProp) && TryGetInt64(valueProp, out value))
                return true;
            if (element.TryGetProperty("raw", out var rawProp) && TryGetInt64(rawProp, out value))
                return true;
        }

        value = 0;
        return false;
    }

    private static async Task<(int ExitCode, string Output)> RunSmartCtlAsync(string exe, string args, int timeoutMs)
    {
        try
        {
            var psi = new ProcessStartInfo
            {
                FileName = exe,
                Arguments = args,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true,
                StandardOutputEncoding = Encoding.UTF8,
                StandardErrorEncoding = Encoding.UTF8,
            };

            using var p = new Process { StartInfo = psi };
            p.Start();
            var stdoutTask = p.StandardOutput.ReadToEndAsync();
            var stderrTask = p.StandardError.ReadToEndAsync();
            var exited = await Task.Run(() => p.WaitForExit(timeoutMs));
            if (!exited)
            {
                try { p.Kill(); } catch { }
                return (-999, "");
            }

            var stdout = await stdoutTask;
            var stderr = await stderrTask;
            return (p.ExitCode, string.IsNullOrWhiteSpace(stdout) ? stderr : stdout);
        }
        catch
        {
            return (-998, "");
        }
    }

    private static string FindSmartCtlExe()
    {
        var baseDir = AppContext.BaseDirectory;
        var candidates = new List<string>
        {
            Path.Combine(baseDir, "smartctl.exe"),
            Path.Combine(baseDir, "tools", "smartctl.exe"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "smartmontools", "bin", "smartctl.exe"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "smartmontools", "bin", "smartctl.exe"),
        };

        var path = Environment.GetEnvironmentVariable("PATH") ?? string.Empty;
        foreach (var dir in path.Split(Path.PathSeparator, StringSplitOptions.RemoveEmptyEntries))
        {
            try { candidates.Add(Path.Combine(dir.Trim(), "smartctl.exe")); } catch { }
        }

        return candidates.FirstOrDefault(File.Exists) ?? string.Empty;
    }

    private static string Quote(string value) => "\"" + value.Replace("\"", "\\\"") + "\"";
}

internal static class DiskScanner
{
    internal static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true,
    };

    public static async Task<IReadOnlyList<DiskInfo>> GetPhysicalDisksAsync(bool enrichWithSmartCtl = false)
    {
        // Stabilitätsfix v59:
        // Der Dauerscan darf keine StorageReliabilityCounter-/PhysicalDisk-Abfragen mehr ausführen.
        // Diese PowerShell-Cmdlets können bei USB-NVMe-Bridges den Windows-Storage-Stack blockieren.
        // SMART/Wear wird weiterhin beim tatsächlichen Test per CrystalDiskInfo/smartctl ergänzt.
        var script = """
$ErrorActionPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$items = @()

function Clean-TextValue {
    param([object]$Value)
    if ($null -eq $Value) { return '' }
    $s = [string]$Value
    $s = $s -replace '[\x00-\x1F\x7F\uFFFD]', ''
    return $s.Trim()
}

function Normalize-Serial {
    param([object]$Value)
    $s = Clean-TextValue $Value
    if ([string]::IsNullOrWhiteSpace($s)) { return '' }
    $s = $s -replace '^SCSI\\Disk&Ven_[^\\]+\\', ''
    $s = $s -replace '^USBSTOR\\Disk&Ven_[^\\]+\\', ''
    $s = $s.Trim()
    if ($s -match '^(?:[A-Za-z0-9]\s+){4,}[A-Za-z0-9]$') { $s = ($s -replace '\s+', '') }
    return $s.Trim()
}

function Get-SerialFromPnp {
    param([string]$PnpDeviceId)
    $p = Clean-TextValue $PnpDeviceId
    if ([string]::IsNullOrWhiteSpace($p)) { return '' }
    $parts = $p -split '\\'
    if ($parts.Count -lt 2) { return '' }
    $tail = ($parts[-1] -split '&')[0]
    return (Normalize-Serial $tail)
}

function Test-GoodSerial {
    param([string]$Value)
    $s = Normalize-Serial $Value
    if ([string]::IsNullOrWhiteSpace($s)) { return $false }
    if ($s.Length -lt 4) { return $false }
    if ($s -match '^(0+|\?+|\.+|_+|-+)$') { return $false }
    if ($s -match '(?i)^(to be filled|none|unknown|default|string|serial|number|n/a)$') { return $false }
    if ($s -notmatch '^[A-Za-z0-9][A-Za-z0-9_\.\-]{3,}$') { return $false }
    if ($s -match '(?i)^(disk|ven|prod|rev|usb|scsi)$') { return $false }
    $zeroCount = ([regex]::Matches($s, '0')).Count
    if ($s -match '^[0-9A-Fa-f]{12,}$' -and $zeroCount -ge [Math]::Ceiling($s.Length * 0.55)) { return $false }
    if ($s -match '^[0-9A-Fa-f]{16,32}$' -and ($s -match '00000000')) { return $false }
    return $true
}

function Get-BestSerial {
    param([object[]]$Candidates)
    foreach ($candidate in $Candidates) {
        $s = Normalize-Serial $candidate
        if (Test-GoodSerial $s) { return $s }
    }
    return 'n/a'
}

$allDisks = @(Get-Disk -ErrorAction SilentlyContinue)
$wmiDisks = @(Get-CimInstance Win32_DiskDrive -ErrorAction SilentlyContinue)

foreach ($d in $allDisks) {
    $wmi = $wmiDisks | Where-Object { $_.Index -eq $d.Number } | Select-Object -First 1

    $driveLetters = @()
    try {
        $parts = @(Get-Partition -DiskNumber $d.Number -ErrorAction SilentlyContinue | Where-Object { $_.DriveLetter })
        foreach ($part in $parts) {
            if ($part.DriveLetter) { $driveLetters += [string]$part.DriveLetter }
        }
        $driveLetters = @($driveLetters | Sort-Object -Unique)
    } catch {
        $driveLetters = @()
    }

    $serialCandidates = @(
        $d.SerialNumber,
        $(if ($null -ne $wmi) { $wmi.SerialNumber }),
        $(if ($null -ne $wmi) { Get-SerialFromPnp $wmi.PNPDeviceID }),
        $d.UniqueId
    )
    $serial = Get-BestSerial $serialCandidates

    $friendly = Clean-TextValue $d.FriendlyName
    if ([string]::IsNullOrWhiteSpace($friendly) -and $null -ne $wmi) { $friendly = Clean-TextValue $wmi.Model }

    $items += [pscustomobject]@{
        FriendlyName      = $friendly
        SerialNumber      = $serial
        UniqueId          = Clean-TextValue $d.UniqueId
        BusType           = [string]$d.BusType
        MediaType         = [string]$d.MediaType
        HealthStatus      = [string]$d.HealthStatus
        OperationalStatus = [string](@($d.OperationalStatus) -join ', ')
        DriveLetters      = [string]($driveLetters -join ',')
        DiskNumber        = [int]$d.Number
        SizeBytes         = [UInt64]$d.Size
        SmartAvailable    = $false
        SmartStatusPassed = $null
        CriticalWarning   = $null
        AvailableSpare    = $null
        AvailableSpareThreshold = $null
        ReadErrorsTotal   = $null
        WriteErrorsTotal  = $null
        Temperature       = $null
        Wear              = $null
        LifeRemaining     = $null
        PowerOnHours      = $null
    }
}

ConvertTo-Json -InputObject @($items) -Depth 4 -Compress
""";

        var json = await RunPowerShellAsync(script, timeoutMs: 30000);
        json = json.Trim();

        if (string.IsNullOrWhiteSpace(json))
            return Array.Empty<DiskInfo>();

        using var doc = JsonDocument.Parse(json);
        var result = new List<DiskInfo>();

        if (doc.RootElement.ValueKind == JsonValueKind.Array)
        {
            foreach (var element in doc.RootElement.EnumerateArray())
            {
                var disk = element.Deserialize<DiskInfo>(JsonOptions);
                if (disk != null)
                {
                    NormalizeDisk(disk);
                    if (enrichWithSmartCtl)
                        await SmartCtl.EnrichAsync(disk);
                    result.Add(disk);
                }
            }
        }
        else if (doc.RootElement.ValueKind == JsonValueKind.Object)
        {
            var disk = doc.RootElement.Deserialize<DiskInfo>(JsonOptions);
            if (disk != null)
            {
                NormalizeDisk(disk);
                if (enrichWithSmartCtl)
                    await SmartCtl.EnrichAsync(disk);
                result.Add(disk);
            }
        }

        return result;
    }

    public static async Task<MountResult> EnsureMountedOrPrepareForReadWriteAsync(DiskInfo disk)
    {
        if (!disk.DiskNumber.HasValue)
            return new MountResult { Success = false, Message = "Keine DiskNumber vorhanden.", Action = "Initialisierung/Format/Mount fehlgeschlagen." };

        var diskNumber = disk.DiskNumber.Value;
        var tempLabel = "NQ" + Random.Shared.Next(0, int.MaxValue).ToString("X8", CultureInfo.InvariantCulture);
        var log = new List<string>();

        void AddLog(string text)
        {
            try { log.Add(DateTime.Now.ToString("HH:mm:ss.fff", CultureInfo.InvariantCulture) + "  " + text); } catch { }
        }

        MountResult Finish(bool success, string testPath, string action, string message)
        {
            var fullMessage = message ?? string.Empty;
            if (log.Count > 0)
            {
                var joined = string.Join(Environment.NewLine, log);
                fullMessage = string.IsNullOrWhiteSpace(fullMessage)
                    ? joined
                    : fullMessage + Environment.NewLine + "\n\nAblauf:" + Environment.NewLine + joined;
            }

            return new MountResult
            {
                Success = success,
                TestPath = NormalizeAccessPath(testPath),
                Action = action,
                Message = fullMessage,
                DriveLetters = ExtractDriveLettersFromPath(testPath)
            };
        }

        async Task<MountResult?> TryPrepareAndFormatAsync(string partitionStyle, string letter)
        {
            AddLog($"PreAssignFormat-{partitionStyle.ToUpperInvariant()}: DiskPart initialisiert, formatiert ohne RAW-Mount und weist den Buchstaben erst danach zu.");

            var init = await RunDiskPartAsync(
                $"preassign-format-{partitionStyle}-{letter}",
                BuildPrepareFormatThenAssignCommands(diskNumber, partitionStyle, letter, tempLabel),
                70000,
                AddLog);

            if (DiskPartOutputHasHardError(init))
            {
                AddLog($"PreAssignFormat-{partitionStyle.ToUpperInvariant()}: DiskPart meldete harten Fehler.");
                return null;
            }

            var letterPath = letter + @":\";

            // Der Buchstabe wird erst nach der NTFS-Formatierung zugewiesen. Dadurch wird keine RAW-Partition gemountet.
            if (await WaitWritableAsync(letterPath, 24, 125))
            {
                return Finish(true, letterPath,
                    $"Datenträger wurde initialisiert, ohne RAW-Mount NTFS-quick-formatiert und als {letter}: bereitgestellt.",
                    string.Empty);
            }

            var byLabel = await WaitWritablePathByVolumeLabelAsync(tempLabel, 8, 150);
            if (!string.IsNullOrWhiteSpace(byLabel))
            {
                return Finish(true, byLabel,
                    $"Datenträger wurde formatiert; schreibbarer Pfad nach Label-Suche erkannt: {NormalizeAccessPath(byLabel).TrimEnd('\\')}.",
                    string.Empty);
            }

            AddLog($"{letter}: wurde nach Formatierung nicht schnell sichtbar; Assign wird einmal repariert, ohne erneutes Formatieren.");
            var assign = await RunDiskPartAsync("assign-repair-after-format-" + letter, BuildAssignOnlyCommands(diskNumber, letter), 20000, AddLog);
            _ = assign;

            if (await WaitWritableAsync(letterPath, 20, 150))
            {
                return Finish(true, letterPath,
                    $"Datenträger wurde formatiert; Laufwerksbuchstabe {letter}: wurde nachträglich repariert.",
                    string.Empty);
            }

            byLabel = await WaitWritablePathByVolumeLabelAsync(tempLabel, 6, 150);
            if (!string.IsNullOrWhiteSpace(byLabel))
            {
                return Finish(true, byLabel,
                    $"Datenträger wurde formatiert; schreibbarer Pfad nach Assign-Reparatur per Label erkannt: {NormalizeAccessPath(byLabel).TrimEnd('\\')}.",
                    string.Empty);
            }

            AddLog("Formatierung abgeschlossen, aber Volume wurde nicht rechtzeitig schreibbar erkannt.");
            return Finish(false, string.Empty, "Initialisierung/Format/Mount fehlgeschlagen.",
                $"{letter}: wurde per DiskPart formatiert, war danach aber nicht schreibbar sichtbar.");
        }


        try
        {
            AddLog($"Format-/Mount-System v33 PreAssignFormat gestartet. Disk={diskNumber}");

            if (DiskDriveListContainsSystemDrive(disk.DriveLetters))
            {
                return Finish(false, string.Empty, "Sicherheitsabbruch.",
                    $"Datenträger {diskNumber} enthält das Systemlaufwerk und wird nicht bearbeitet.");
            }

            var smallPartitionProbe = await DetectSmallExistingPartitionsAsync(diskNumber, 1000UL * 1000UL * 1000UL);
            if (smallPartitionProbe.HasSmallPartition)
            {
                AddLog("Kleine vorhandene Partition <1000 MB erkannt: " + smallPartitionProbe.Details);
                AddLog("Vorhandene Volumes werden nicht direkt getestet; Datenträger wird per Clean neu initialisiert und formatiert.");
            }
            else
            {
                // Bereits schreibbare, manuell formatierte Laufwerke sofort nutzen.
                var existing = FindWritablePathFromDriveLetters(disk.DriveLetters);
                if (!string.IsNullOrWhiteSpace(existing))
                {
                    return Finish(true, existing,
                        "Vorhandenes schreibbares Volume wurde direkt für den R/W-Test verwendet; keine Initialisierung und keine Formatierung.",
                        string.Empty);
                }
            }

            var letter = GetFreeDriveLetter();
            if (string.IsNullOrWhiteSpace(letter))
            {
                return Finish(false, string.Empty, "Initialisierung/Format/Mount fehlgeschlagen.",
                    "Kein freier Laufwerksbuchstabe gefunden.");
            }

            AddLog($"Freier Test-Laufwerksbuchstabe: {letter}:");

            var gptResult = await TryPrepareAndFormatAsync("gpt", letter);
            if (gptResult != null && gptResult.Success)
                return gptResult;

            AddLog("GPT/PreAssignFormat war nicht erfolgreich; MBR-Fallback wird einmal versucht.");
            var mbrResult = await TryPrepareAndFormatAsync("mbr", letter);
            if (mbrResult != null)
                return mbrResult;

            return Finish(false, string.Empty, "Initialisierung/Format/Mount fehlgeschlagen.",
                $"Weder GPT noch MBR konnten Datenträger {diskNumber} schnell initialisieren/formatieren/mounten.");
        }
        catch (Exception ex)
        {
            return Finish(false, string.Empty, "Initialisierung/Format/Mount fehlgeschlagen.", ex.Message);
        }
    }

    private sealed class SmallPartitionProbe
    {
        public bool HasSmallPartition { get; init; }
        public string Details { get; init; } = string.Empty;
    }

    private static async Task<SmallPartitionProbe> DetectSmallExistingPartitionsAsync(int diskNumber, ulong limitBytes)
    {
        var script = $$"""
$ErrorActionPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$diskNumber = {{diskNumber}}
$limitBytes = [UInt64]{{limitBytes}}
$items = @()
try {
    $parts = @(Get-Partition -DiskNumber $diskNumber -ErrorAction SilentlyContinue)
    foreach ($p in $parts) {
        $size = [UInt64]$p.Size
        if ($size -gt 0 -and $size -lt $limitBytes) {
            $items += [pscustomobject]@{
                PartitionNumber = [int]$p.PartitionNumber
                SizeMB          = [math]::Round($size / 1MB, 1)
                DriveLetter     = [string]$p.DriveLetter
                Type            = [string]$p.Type
            }
        }
    }
} catch { }
[pscustomobject]@{
    HasSmallPartition = [bool]($items.Count -gt 0)
    Details = [string](($items | ForEach-Object {
        $letter = if ([string]::IsNullOrWhiteSpace($_.DriveLetter)) { '-' } else { $_.DriveLetter }
        ('#{0}: {1} MB, Letter={2}, Type={3}' -f $_.PartitionNumber, $_.SizeMB, $letter, $_.Type)
    }) -join '; ')
} | ConvertTo-Json -Compress
""";

        try
        {
            var json = (await RunPowerShellAsync(script, timeoutMs: 8000)).Trim();
            if (string.IsNullOrWhiteSpace(json))
                return new SmallPartitionProbe();

            using var doc = JsonDocument.Parse(json);
            var has = doc.RootElement.TryGetProperty("HasSmallPartition", out var hasElement) && hasElement.ValueKind == JsonValueKind.True;
            var details = doc.RootElement.TryGetProperty("Details", out var detailsElement) ? detailsElement.GetString() ?? string.Empty : string.Empty;
            return new SmallPartitionProbe { HasSmallPartition = has, Details = CleanDisplayText(details) };
        }
        catch
        {
            return new SmallPartitionProbe();
        }
    }

    private sealed class DiskPartRun
    {
        public string Name { get; init; } = string.Empty;
        public int ExitCode { get; init; }
        public string Output { get; init; } = string.Empty;
        public string Script { get; init; } = string.Empty;
    }


    private static string[] BuildPrepareFormatThenAssignCommands(int diskNumber, string partitionStyle, string letter, string label)
    {
        var cleanLabel = new string((label ?? "NVMEQC").Where(ch => char.IsLetterOrDigit(ch) || ch == '_' || ch == '-').Take(11).ToArray());
        if (string.IsNullOrWhiteSpace(cleanLabel))
            cleanLabel = "NVMEQC";

        return new[]
        {
            "san policy=OnlineAll",
            "automount enable",
            $"select disk {diskNumber}",
            "online disk noerr",
            "attributes disk clear readonly noerr",
            "clean",
            $"convert {partitionStyle}",
            "create partition primary",
            "select partition 1",
            $"format fs=ntfs quick unit=64k label={cleanLabel}",
            $"assign letter={letter} noerr",
            "exit"
        };
    }


    private static string[] BuildAssignOnlyCommands(int diskNumber, string letter)
    {
        return new[]
        {
            $"select disk {diskNumber}",
            "select partition 1",
            $"assign letter={letter} noerr",
            "exit"
        };
    }

    private static async Task<DiskPartRun> RunDiskPartAsync(string name, IReadOnlyList<string> commands, int timeoutMs, Action<string> addLog)
    {
        var scriptContent = string.Join(Environment.NewLine, commands) + Environment.NewLine;
        var scriptPath = Path.Combine(Path.GetTempPath(), "NvmeUsbQuickCheck_DiskPart_" + Guid.NewGuid().ToString("N") + ".txt");

        addLog("DiskPart-Script: " + name);
        addLog(string.Join(" | ", commands));

        await File.WriteAllTextAsync(scriptPath, scriptContent, Encoding.ASCII);

        try
        {
            var psi = new ProcessStartInfo
            {
                FileName = "diskpart.exe",
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true,
                StandardOutputEncoding = Encoding.UTF8,
                StandardErrorEncoding = Encoding.UTF8,
            };
            psi.ArgumentList.Add("/s");
            psi.ArgumentList.Add(scriptPath);

            using var process = new Process { StartInfo = psi };
            process.Start();
            var stdoutTask = process.StandardOutput.ReadToEndAsync();
            var stderrTask = process.StandardError.ReadToEndAsync();

            using var timeout = new CancellationTokenSource(timeoutMs);
            try
            {
                await process.WaitForExitAsync(timeout.Token);
            }
            catch (OperationCanceledException)
            {
                try
                {
                    if (!process.HasExited)
                        process.Kill(entireProcessTree: true);
                }
                catch { }

                addLog($"DiskPart {name}: Timeout nach {timeoutMs} ms");
                return new DiskPartRun
                {
                    Name = name,
                    ExitCode = -900,
                    Output = $"DiskPart Timeout nach {timeoutMs} ms",
                    Script = scriptContent
                };
            }

            var stdout = await stdoutTask;
            var stderr = await stderrTask;
            var output = (stdout + Environment.NewLine + stderr).Trim();
            var shortOutput = output.Length > 5000 ? output[..5000] + " ... gekürzt" : output;
            addLog($"DiskPart {name}: ExitCode={process.ExitCode}{Environment.NewLine}{shortOutput}");

            return new DiskPartRun
            {
                Name = name,
                ExitCode = process.ExitCode,
                Output = output,
                Script = scriptContent
            };
        }
        finally
        {
            try { File.Delete(scriptPath); } catch { }
        }
    }

    private static readonly string[] DiskPartHardErrorPhrases =
    {
        "virtual disk service error",
        "fehler des dienstes",
        "diskpart has encountered an error",
        "diskpart encountered an error",
        "zugriff verweigert",
        "access is denied",
        "schreibgeschützt",
        "write protected",
        "das gerät ist nicht bereit",
        "the device is not ready",
        "das system kann die angegebene datei nicht finden",
        "the system cannot find the file specified"
    };

    private static bool DiskPartOutputHasHardError(DiskPartRun? result)
    {
        if (result == null)
            return true;
        if (result.ExitCode != 0)
            return true;
        if (string.IsNullOrWhiteSpace(result.Output))
            return false;

        var text = result.Output.ToLowerInvariant();
        return DiskPartHardErrorPhrases.Any(text.Contains);
    }

    private static string GetFreeDriveLetter()
    {
        var used = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        try
        {
            foreach (var drive in DriveInfo.GetDrives())
            {
                if (!string.IsNullOrWhiteSpace(drive.Name))
                    used.Add(drive.Name[..1]);
            }
        }
        catch { }

        foreach (var letter in new[] { "Z", "Y", "X", "W", "V", "U", "T", "S", "R", "Q", "P", "O", "N", "M", "L", "K", "J", "I", "H", "G", "F", "E" })
        {
            if (!used.Contains(letter) && !Directory.Exists(letter + @":\"))
                return letter;
        }

        return string.Empty;
    }

    private static string FindWritablePathFromDriveLetters(string? driveLetters)
    {
        if (string.IsNullOrWhiteSpace(driveLetters))
            return string.Empty;

        foreach (var raw in driveLetters.Split(new[] { ',', ';', ' ' }, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            var letter = raw.Trim().TrimEnd(':', '\\');
            if (letter.Length != 1)
                continue;

            var path = letter + @":\";
            if (IsPathWritable(path))
                return NormalizeAccessPath(path);
        }

        return string.Empty;
    }

    private static bool DiskDriveListContainsSystemDrive(string? driveLetters)
    {
        var system = Environment.GetEnvironmentVariable("SystemDrive") ?? string.Empty;
        system = system.Trim().TrimEnd(':', '\\');
        if (string.IsNullOrWhiteSpace(system) || string.IsNullOrWhiteSpace(driveLetters))
            return false;

        foreach (var raw in driveLetters.Split(new[] { ',', ';', ' ' }, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            var letter = raw.Trim().TrimEnd(':', '\\');
            if (string.Equals(letter, system, StringComparison.OrdinalIgnoreCase))
                return true;
        }

        return false;
    }


    private static async Task<bool> WaitWritableAsync(string path, int attempts, int delayMs)
    {
        var normalized = NormalizeAccessPath(path);
        for (var i = 0; i < attempts; i++)
        {
            if (IsPathWritable(normalized))
                return true;
            await Task.Delay(delayMs);
        }

        return false;
    }

    private static async Task<string> WaitWritablePathByVolumeLabelAsync(string label, int attempts, int delayMs)
    {
        for (var i = 0; i < attempts; i++)
        {
            var path = FindWritablePathByVolumeLabel(label);
            if (!string.IsNullOrWhiteSpace(path))
                return NormalizeAccessPath(path);
            await Task.Delay(delayMs);
        }

        return string.Empty;
    }

    private static string FindWritablePathByVolumeLabel(string label)
    {
        if (string.IsNullOrWhiteSpace(label))
            return string.Empty;

        try
        {
            foreach (var drive in DriveInfo.GetDrives())
            {
                try
                {
                    if (!drive.IsReady)
                        continue;
                    if (!string.Equals(drive.VolumeLabel, label, StringComparison.OrdinalIgnoreCase))
                        continue;
                    if (IsPathWritable(drive.RootDirectory.FullName))
                        return NormalizeAccessPath(drive.RootDirectory.FullName);
                }
                catch { }
            }
        }
        catch { }

        return string.Empty;
    }

    private static bool IsPathWritable(string path)
    {
        var normalized = NormalizeAccessPath(path);
        if (string.IsNullOrWhiteSpace(normalized) || !Directory.Exists(normalized))
            return false;

        try
        {
            var probe = Path.Combine(normalized, ".nvme_probe_" + Guid.NewGuid().ToString("N") + ".tmp");
            File.WriteAllText(probe, "probe", Encoding.ASCII);
            try { File.Delete(probe); } catch { }
            return true;
        }
        catch
        {
            return false;
        }
    }

    private static string NormalizeAccessPath(string? path)
    {
        if (string.IsNullOrWhiteSpace(path))
            return string.Empty;
        var p = path.Trim().Trim('"');
        if (p.Length == 2 && p[1] == ':')
            p += @"\";
        if (!p.EndsWith(@"\", StringComparison.Ordinal))
            p += @"\";
        return p;
    }

    private static string ExtractDriveLettersFromPath(string? path)
    {
        var normalized = NormalizeAccessPath(path);
        if (normalized.Length >= 2 && normalized[1] == ':')
            return normalized[..1].ToUpperInvariant();
        return string.Empty;
    }

    private static void NormalizeDisk(DiskInfo disk)
    {
        disk.FriendlyName = CleanDisplayText(disk.FriendlyName);
        disk.SerialNumber = CleanDisplayText(disk.SerialNumber);
        disk.UniqueId = CleanDisplayText(disk.UniqueId);
        disk.BusType = CleanDisplayText(disk.BusType);
        disk.MediaType = CleanDisplayText(disk.MediaType);
        disk.HealthStatus = CleanDisplayText(disk.HealthStatus);
        disk.OperationalStatus = CleanDisplayText(disk.OperationalStatus);
        disk.DriveLetters = CleanDisplayText(disk.DriveLetters);
        disk.SmartSource = CleanDisplayText(disk.SmartSource);
        disk.SmartDetails = CleanDisplayText(disk.SmartDetails);
        disk.WearLevelText = CleanDisplayText(disk.WearLevelText);
    }

    private static string CleanDisplayText(string? value)
    {
        if (string.IsNullOrEmpty(value))
            return string.Empty;

        var sb = new StringBuilder(value.Length);
        foreach (var ch in value)
        {
            if (!char.IsControl(ch))
                sb.Append(ch);
        }

        return sb.ToString().Trim();
    }

    private static async Task<string> RunPowerShellAsync(string script, int timeoutMs)
    {
        // Wichtig: keine langen -EncodedCommand-Argumente verwenden.
        // Auf manchen Systemen schlägt Process.Start sonst mit
        // "Der Dateiname oder die Erweiterung ist zu lang" fehl.
        // Zusätzlich schützt ein harter Timeout den Scanner davor, dauerhaft in PowerShell/DiskPart zu hängen.
        var scriptPath = Path.Combine(
            Path.GetTempPath(),
            "NvmeUsbQuickCheck_" + Guid.NewGuid().ToString("N") + ".ps1");

        await File.WriteAllTextAsync(
            scriptPath,
            script,
            new UTF8Encoding(encoderShouldEmitUTF8Identifier: true));

        try
        {
            var psi = new ProcessStartInfo
            {
                FileName = "powershell.exe",
                Arguments = "-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File \"" + scriptPath + "\"",
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true,
                StandardOutputEncoding = Encoding.UTF8,
                StandardErrorEncoding = Encoding.UTF8,
            };

            using var process = new Process { StartInfo = psi };
            process.Start();
            var stdoutTask = process.StandardOutput.ReadToEndAsync();
            var stderrTask = process.StandardError.ReadToEndAsync();

            using var timeout = new CancellationTokenSource(timeoutMs);
            try
            {
                await process.WaitForExitAsync(timeout.Token);
            }
            catch (OperationCanceledException)
            {
                try
                {
                    if (!process.HasExited)
                        process.Kill(entireProcessTree: true);
                }
                catch { }

                throw new TimeoutException($"PowerShell-Scan hat nach {timeoutMs} ms nicht geantwortet und wurde beendet.");
            }

            var stdout = await stdoutTask;
            var stderr = await stderrTask;

            if (process.ExitCode != 0)
            {
                throw new InvalidOperationException("PowerShell konnte den Datenträger-Befehl nicht ausführen: " + stderr);
            }

            if (string.IsNullOrWhiteSpace(stdout) && !string.IsNullOrWhiteSpace(stderr))
            {
                throw new InvalidOperationException(stderr);
            }

            return stdout;
        }
        finally
        {
            try { File.Delete(scriptPath); } catch { }
        }
    }

}

internal static class CsvResultExporter
{
    private static readonly string[] Headers =
    {
        "Zeit", "Ergebnis", "Name", "Seriennummer", "Größe", "Health", "SMART", "Hours", "R/W"
    };

    public static void Export(string filePath, IReadOnlyList<ExportResultSnapshot> results)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(filePath)) ?? ".");
        using var writer = new StreamWriter(filePath, false, new UTF8Encoding(encoderShouldEmitUTF8Identifier: true));
        WriteHeader(writer);
        foreach (var result in results)
            WriteResult(writer, result);
    }

    public static void AppendDailyLog(ExportResultSnapshot result)
    {
        try
        {
            var dir = LogDirectory;
            Directory.CreateDirectory(dir);
            CleanupOldDailyLogs(AppSettings.Load().LogRetentionDays);
            var file = Path.Combine(dir, $"NvmeUsbQuickCheck_{DateTime.Now:yyyy-MM-dd}.csv");
            var writeHeader = !File.Exists(file) || new FileInfo(file).Length == 0;
            using var writer = new StreamWriter(file, true, new UTF8Encoding(encoderShouldEmitUTF8Identifier: writeHeader));
            if (writeHeader)
                WriteHeader(writer);
            WriteResult(writer, result);
        }
        catch
        {
            // Tageslog darf den Testablauf niemals blockieren.
        }
    }

    public static void CleanupOldDailyLogs(int retentionDays)
    {
        try
        {
            retentionDays = Math.Clamp(retentionDays, 1, 3650);
            var dir = LogDirectory;
            if (!Directory.Exists(dir))
                return;

            var deleteBefore = DateTime.Today.AddDays(-retentionDays);
            foreach (var file in Directory.EnumerateFiles(dir, "NvmeUsbQuickCheck_*.csv", SearchOption.TopDirectoryOnly))
            {
                try
                {
                    var name = Path.GetFileNameWithoutExtension(file);
                    const string prefix = "NvmeUsbQuickCheck_";
                    if (!name.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                        continue;

                    var datePart = name[prefix.Length..];
                    if (!DateTime.TryParseExact(datePart, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out var logDate))
                        continue;

                    if (logDate.Date < deleteBefore)
                        File.Delete(file);
                }
                catch { }
            }
        }
        catch
        {
            // Log-Bereinigung darf die App niemals blockieren.
        }
    }

    private static string LogDirectory =>
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "NvmeUsbQuickCheck", "Logs");

    private static void WriteHeader(TextWriter writer) => writer.WriteLine(string.Join(";", Headers.Select(Escape)));

    private static void WriteResult(TextWriter writer, ExportResultSnapshot result)
    {
        var values = new[]
        {
            result.Timestamp.ToString("yyyy-MM-dd HH:mm:ss"),
            result.Result,
            result.Name,
            result.SerialNumber,
            result.Size,
            result.Health,
            result.Smart,
            result.Hours,
            result.ReadWrite
        };
        writer.WriteLine(string.Join(";", values.Select(Escape)));
    }

    private static string Escape(string? value)
    {
        var v = (value ?? string.Empty).Replace("\r", " ").Replace("\n", " ").Trim();
        if (v.Contains(';') || v.Contains('"'))
            return "\"" + v.Replace("\"", "\"\"") + "\"";
        return v;
    }
}

internal static class PdfResultExporter
{
    public static void Export(string filePath, IReadOnlyList<ExportResultSnapshot> results, string filterLabel)
    {
        if (results.Count == 0)
            throw new InvalidOperationException("Keine Ergebnisse zum Exportieren vorhanden.");

        var pdf = new SimplePdfDocument(842f, 595f, 30f); // A4 quer
        pdf.AddText("USB-NVMe Schnelltest - Prüfergebnisse", 16f, true);
        pdf.AddText($"Export: {DateTime.Now:yyyy-MM-dd HH:mm:ss}    Filter: {filterLabel}    Anzahl: {results.Count}", 9f, false);
        pdf.AddSpace(10f);

        var headers = new[] { "Zeit", "Ergebnis", "Name", "Seriennummer", "Größe", "Health", "SMART", "Hours", "R/W" };
        var rows = results.Select(result => new[]
        {
            result.Timestamp.ToString("HH:mm:ss"),
            result.Result,
            result.Name,
            result.SerialNumber,
            result.Size,
            result.Health,
            result.Smart,
            result.Hours,
            result.ReadWrite
        }).ToList();

        var widths = CalculateColumnWidths(headers, rows, 842f - 60f);
        pdf.DrawTableRow(headers, widths, true);

        foreach (var cells in rows)
        {
            if (!pdf.CanFit(pdf.MeasureTableRowHeight(cells, widths, 7.6f, 4)))
            {
                pdf.NewPage();
                pdf.DrawTableRow(headers, widths, true);
            }

            pdf.DrawTableRow(cells, widths, false);
        }

        // Detailansicht bewusst nicht exportieren: PDF enthält nur die gefilterte Ergebnistabelle.
        pdf.Save(filePath);
    }

    private static float[] CalculateColumnWidths(string[] headers, IReadOnlyList<string[]> rows, float totalWidth)
    {
        var minWidths = new[] { 42f, 58f, 78f, 82f, 55f, 65f, 45f, 45f, 120f };
        var maxWidths = new[] { 58f, 78f, 155f, 155f, 72f, 118f, 92f, 70f, 230f };
        var desired = new float[headers.Length];

        for (var column = 0; column < headers.Length; column++)
        {
            var maxLen = DisplayLength(headers[column]);
            foreach (var row in rows)
            {
                if (column < row.Length)
                    maxLen = Math.Max(maxLen, DisplayLength(row[column]));
            }

            var estimated = 14f + Math.Min(maxLen, 52) * 4.4f;
            desired[column] = Math.Clamp(estimated, minWidths[column], maxWidths[column]);
        }

        FitWidthsToTotal(desired, minWidths, maxWidths, totalWidth);
        return desired;
    }

    private static void FitWidthsToTotal(float[] widths, float[] minWidths, float[] maxWidths, float totalWidth)
    {
        var current = widths.Sum();
        if (Math.Abs(current - totalWidth) < 0.5f)
            return;

        if (current > totalWidth)
        {
            var overflow = current - totalWidth;
            for (var pass = 0; pass < 8 && overflow > 0.5f; pass++)
            {
                var shrinkable = widths.Select((w, i) => Math.Max(0f, w - minWidths[i])).Sum();
                if (shrinkable <= 0.1f)
                    break;

                for (var i = 0; i < widths.Length; i++)
                {
                    var canShrink = Math.Max(0f, widths[i] - minWidths[i]);
                    if (canShrink <= 0f)
                        continue;

                    var shrink = Math.Min(canShrink, overflow * (canShrink / shrinkable));
                    widths[i] -= shrink;
                }

                overflow = widths.Sum() - totalWidth;
            }
        }
        else
        {
            var remaining = totalWidth - current;
            var preferredOrder = new[] { 8, 2, 3, 5, 6, 1, 7, 4, 0 };
            foreach (var i in preferredOrder)
            {
                if (remaining <= 0.5f)
                    break;

                var add = Math.Min(maxWidths[i] - widths[i], remaining);
                if (add <= 0)
                    continue;

                widths[i] += add;
                remaining -= add;
            }
        }
    }

    private static int DisplayLength(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return 0;

        var text = value.Replace("\r", " ").Replace("\n", " ").Trim();
        return text.Length;
    }
}

internal sealed class SimplePdfDocument
{
    private readonly float _pageWidth;
    private readonly float _pageHeight;
    private readonly float _margin;
    private readonly List<StringBuilder> _pages = new();
    private StringBuilder _content = new();
    private float _y;

    public SimplePdfDocument(float pageWidth, float pageHeight, float margin)
    {
        _pageWidth = pageWidth;
        _pageHeight = pageHeight;
        _margin = margin;
        NewPage();
    }

    public void NewPage()
    {
        _content = new StringBuilder();
        _pages.Add(_content);
        _y = _pageHeight - _margin;
    }

    public bool CanFit(float height) => _y - height >= _margin;

    public void EnsureSpace(float height)
    {
        if (!CanFit(height))
            NewPage();
    }

    public void AddSpace(float height)
    {
        EnsureSpace(height);
        _y -= height;
    }

    public void AddText(string text, float fontSize, bool bold)
    {
        EnsureSpace(fontSize + 6f);
        DrawText(_margin, _y, text, fontSize, bold);
        _y -= fontSize + 5f;
    }

    public void AddWrappedText(string text, float fontSize, int maxCharactersPerLine)
    {
        foreach (var rawLine in text.Replace("\r", string.Empty).Split('\n'))
        {
            var wrapped = WrapByCharacters(rawLine, maxCharactersPerLine).ToList();
            if (wrapped.Count == 0)
                wrapped.Add(string.Empty);

            foreach (var line in wrapped)
            {
                EnsureSpace(fontSize + 4f);
                DrawText(_margin, _y, line, fontSize, false);
                _y -= fontSize + 3f;
            }
        }
    }

    public float MeasureTableRowHeight(string[] cells, float[] widths, float fontSize, int maxLines)
    {
        var max = 1;
        for (var i = 0; i < cells.Length; i++)
        {
            var lines = WrapCell(cells[i], widths[i], fontSize, maxLines).Count;
            if (lines > max)
                max = lines;
        }

        return Math.Max(20f, 8f + max * (fontSize + 2f));
    }

    public void DrawTableRow(string[] cells, float[] widths, bool header)
    {
        var fontSize = header ? 8.5f : 8f;
        var maxLines = header ? 2 : 3;
        var rowHeight = MeasureTableRowHeight(cells, widths, fontSize, maxLines);
        EnsureSpace(rowHeight);

        var x = _margin;
        for (var i = 0; i < cells.Length; i++)
        {
            DrawRectangle(x, _y - rowHeight, widths[i], rowHeight);
            var lines = WrapCell(cells[i], widths[i], fontSize, maxLines);
            var textY = _y - 13f;
            foreach (var line in lines)
            {
                DrawText(x + 3f, textY, line, fontSize, header);
                textY -= fontSize + 2f;
            }

            x += widths[i];
        }

        _y -= rowHeight;
    }

    public void Save(string filePath)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(filePath)) ?? ".");

        using var stream = new FileStream(filePath, FileMode.Create, FileAccess.Write, FileShare.None);
        var offsets = new List<long> { 0 };

        WriteRaw(stream, "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n");

        WriteObject(stream, offsets, 1, "<< /Type /Catalog /Pages 2 0 R >>\n");

        var kids = new StringBuilder();
        for (var i = 0; i < _pages.Count; i++)
            kids.Append($"{4 + i * 2} 0 R ");

        WriteObject(stream, offsets, 2, $"<< /Type /Pages /Count {_pages.Count} /Kids [ {kids}] >>\n");
        WriteObject(stream, offsets, 3, "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>\n");
        WriteObject(stream, offsets, 4 + _pages.Count * 2, "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>\n");
        var boldFontObject = 4 + _pages.Count * 2;

        for (var i = 0; i < _pages.Count; i++)
        {
            var pageObject = 4 + i * 2;
            var contentObject = 5 + i * 2;
            WriteObject(stream, offsets, pageObject,
                $"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {FormatNumber(_pageWidth)} {FormatNumber(_pageHeight)}] /Resources << /Font << /F1 3 0 R /F2 {boldFontObject} 0 R >> >> /Contents {contentObject} 0 R >>\n");

            var bytes = Encoding.Latin1.GetBytes(_pages[i].ToString());
            WriteStreamObject(stream, offsets, contentObject, bytes);
        }

        var xrefOffset = stream.Position;
        WriteRaw(stream, $"xref\n0 {offsets.Count}\n");
        WriteRaw(stream, "0000000000 65535 f \n");
        for (var i = 1; i < offsets.Count; i++)
            WriteRaw(stream, offsets[i].ToString("D10", CultureInfo.InvariantCulture) + " 00000 n \n");

        WriteRaw(stream, $"trailer\n<< /Size {offsets.Count} /Root 1 0 R >>\nstartxref\n{xrefOffset}\n%%EOF\n");
    }

    private void DrawText(float x, float y, string text, float fontSize, bool bold)
    {
        var font = bold ? "/F2" : "/F1";
        _content.Append("BT ");
        _content.Append(font);
        _content.Append(' ');
        _content.Append(FormatNumber(fontSize));
        _content.Append(" Tf ");
        _content.Append(FormatNumber(x));
        _content.Append(' ');
        _content.Append(FormatNumber(y));
        _content.Append(" Td <");
        _content.Append(ToPdfHex(text));
        _content.Append("> Tj ET\n");
    }

    private void DrawRectangle(float x, float y, float width, float height)
    {
        _content.Append(FormatNumber(x));
        _content.Append(' ');
        _content.Append(FormatNumber(y));
        _content.Append(' ');
        _content.Append(FormatNumber(width));
        _content.Append(' ');
        _content.Append(FormatNumber(height));
        _content.Append(" re S\n");
    }

    private static List<string> WrapCell(string? text, float width, float fontSize, int maxLines)
    {
        var maxCharacters = Math.Max(4, (int)Math.Floor(width / (fontSize * 0.52f)));
        var lines = WrapByCharacters(text ?? string.Empty, maxCharacters).ToList();
        if (lines.Count == 0)
            lines.Add(string.Empty);

        if (lines.Count > maxLines)
        {
            lines = lines.Take(maxLines).ToList();
            lines[^1] = TrimWithEllipsis(lines[^1], Math.Max(3, maxCharacters));
        }

        return lines;
    }

    private static IEnumerable<string> WrapByCharacters(string? text, int maxCharacters)
    {
        var value = SanitizeText(text ?? string.Empty);
        if (value.Length == 0)
        {
            yield return string.Empty;
            yield break;
        }

        while (value.Length > maxCharacters)
        {
            var cut = value.LastIndexOf(' ', Math.Min(maxCharacters, value.Length - 1));
            if (cut < Math.Max(8, maxCharacters / 3))
                cut = maxCharacters;

            yield return value[..cut].TrimEnd();
            value = value[cut..].TrimStart();
        }

        yield return value;
    }

    private static string TrimWithEllipsis(string text, int maxCharacters)
    {
        if (text.Length <= maxCharacters)
            return text;
        if (maxCharacters <= 3)
            return "...";
        return text[..(maxCharacters - 3)].TrimEnd() + "...";
    }

    private static string SanitizeText(string text)
    {
        var sb = new StringBuilder(text.Length);
        foreach (var ch in text.Replace('│', '|').Replace('–', '-').Replace('—', '-'))
        {
            if (ch == '\t')
            {
                sb.Append("    ");
                continue;
            }

            if (char.IsControl(ch))
                continue;

            sb.Append(ch <= 255 ? ch : '?');
        }

        return sb.ToString();
    }

    private static string ToPdfHex(string text)
    {
        var cleaned = SanitizeText(text);
        var sb = new StringBuilder(cleaned.Length * 2);
        foreach (var ch in cleaned)
        {
            var b = ch <= 255 ? (byte)ch : (byte)'?';
            sb.Append(b.ToString("X2", CultureInfo.InvariantCulture));
        }

        return sb.ToString();
    }

    private static string FormatNumber(float value) => value.ToString("0.###", CultureInfo.InvariantCulture);

    private static void WriteObject(Stream stream, List<long> offsets, int objectNumber, string body)
    {
        EnsureOffsetSlot(offsets, objectNumber);
        offsets[objectNumber] = stream.Position;
        WriteRaw(stream, $"{objectNumber} 0 obj\n");
        WriteRaw(stream, body);
        WriteRaw(stream, "endobj\n");
    }

    private static void WriteStreamObject(Stream stream, List<long> offsets, int objectNumber, byte[] bytes)
    {
        EnsureOffsetSlot(offsets, objectNumber);
        offsets[objectNumber] = stream.Position;
        WriteRaw(stream, $"{objectNumber} 0 obj\n<< /Length {bytes.Length} >>\nstream\n");
        stream.Write(bytes, 0, bytes.Length);
        WriteRaw(stream, "\nendstream\nendobj\n");
    }

    private static void EnsureOffsetSlot(List<long> offsets, int objectNumber)
    {
        while (offsets.Count <= objectNumber)
            offsets.Add(0);
    }

    private static void WriteRaw(Stream stream, string text)
    {
        var bytes = Encoding.Latin1.GetBytes(text);
        stream.Write(bytes, 0, bytes.Length);
    }
}

}
